# lance-csr local review artifact

Start with `review/pr-drafts/README.md`, `review/review-heads-current.json` and `review/REPRODUCE.md`. Original failed gates remain intact; current acceptance and coordinated integration requirements are explicit.

`source.bundle` preserves all proposed source refs, main and the evidence branch. Verify it with `git bundle verify source.bundle` from an existing clone, then fetch the desired recorded ref from the bundle. No remote publication has occurred.

Run `shasum -a 256 -c SHA256SUMS` in this directory. `raw-index.json` maps original machine paths in immutable receipts to included content-addressed records. These paths are provenance, not prerequisites for regeneration; use the reproduction guide for a new checkout. Wheel digests are pinned, but wheels, build caches, source SF1 tables and archives are excluded. Derived golden query answers are included.

Submitted by David Hughes (@stugorf), with AI Collaboration.
