"""Execute the unmodified reference IC14 and the existing port; functional proof only."""

import ast
import hashlib
import importlib.util
import json
import os
import resource
import subprocess
import sys
import time
from pathlib import Path

root = Path('/private/tmp/lance-csr-benchmark-ic')
os.environ['LANCE_CSR_MODE'] = 'lazy'
spec = importlib.util.spec_from_file_location('ic_queries', root / 'lance_csr/query.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
from lance_csr import _internal


def query_from(path):
    tree = ast.parse(path.read_text())
    fn = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == 'run_query14')
    return next(n.value.value for n in fn.body if isinstance(n, ast.Assign) and n.targets[0].id == 'query')


params = {'person1Id': 1131, 'person2Id': 19791209300775}
queries = {'canonical': query_from(root / 'neo4j/query.py'), 'port': module.PORTS[14]}
prefix = Path(sys.argv[1])
assert not list(prefix.parent.glob(prefix.name + '.*')), 'proof prefix already exists'
with Path(_internal.__file__).open('rb') as extension:
    extension_hash = hashlib.file_digest(extension, 'sha256').hexdigest()
release_proof_path = os.environ.get('LANCE_CSR_RELEASE_PROOF')
if release_proof_path:
    release_proof = json.loads(Path(release_proof_path).read_text())
    assert extension_hash == release_proof['extension_sha256'], 'wrong installed release extension'
    source_commit = release_proof['source_commit']
else:
    source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
manifest = []
for path in sorted((root / 'lance_csr/graph_lance').glob('*.lance/_versions/*.manifest')):
    manifest.append({'file': str(path.relative_to(root)), 'bytes': path.stat().st_size,
                     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
manifest_bytes = json.dumps(manifest, sort_keys=True).encode()
prefix.with_suffix('.manifests.json').write_bytes(manifest_bytes)
prefix.with_suffix('.query.cypher').write_text(queries['canonical'])
prefix.with_suffix('.provenance.json').write_text(json.dumps({
    'params': params,
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'source_commit': source_commit,
    'release_proof': release_proof_path,
    'benchmark_source_commit': subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
    'extension_sha256': extension_hash,
    'source': str(root / 'neo4j/query.py'),
    'source_sha256': hashlib.sha256((root / 'neo4j/query.py').read_bytes()).hexdigest(),
    'manifest_set_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'manifest_count': len(manifest),
    'expected_file_sha256': hashlib.sha256((root / 'expected/ic14.json').read_bytes()).hexdigest(),
}, indent=2))
engine = module.engine()
print(json.dumps({'extension': _internal.__file__, 'mode': module.MODE, 'purpose': 'functional parity; elapsed times are diagnostics, not performance evidence'}), flush=True)
results = {}
for name, query in queries.items():
    if len(sys.argv) > 2 and name != sys.argv[2]:
        continue
    start = time.perf_counter()
    rows = engine.execute(query, params).to_pylist()
    # ORDER BY pathWeight does not define tie order; preserve multiplicity in a sorted multiset.
    canonical = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True, default=str))
    encoded = json.dumps(canonical, sort_keys=True, default=str).encode()
    results[name] = canonical
    expected = [{key.lower(): value for key, value in row.items()} for row in json.loads((root / 'expected/ic14.json').read_text())]
    expected.sort(key=lambda row: json.dumps(row, sort_keys=True, default=str))
    prefix.with_suffix('.' + name + '.json').write_bytes(encoded)
    assert canonical == expected, f'{name} does not match immutable expected/ic14.json'
    print(json.dumps({'query': name, 'query_sha256': hashlib.sha256(query.encode()).hexdigest(), 'seconds': time.perf_counter() - start, 'rows': len(rows), 'golden_matches': True, 'result_sha256': hashlib.sha256(encoded).hexdigest(), 'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}), flush=True)
if len(results) == 2:
    assert results['canonical'] == results['port'], 'canonical IC14 differs from existing port'
    print(json.dumps({'canonical_matches_port': True}), flush=True)
