"""Join immutable first-pass and paired-repeat results without replacing measurements."""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def means(path):
    rows = json.loads(path.read_text())["benchmarks"]
    result = {int(re.search(r"(\d+)$", row["name"])[1]): row["stats"]["mean"] for row in rows}
    assert len(rows) == len(result) and all(value > 0 for value in result.values())
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("root", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--allow-partial", action="store_true")
args = parser.parse_args()
index_path = args.root / "combined-budget-comparison-tables-r1/index.json"
selection_path = args.root / "combined-budget-repeat-selection-r1.json"
repeat_path = args.root / "combined-budget-primary-repeats-r1/plan.json"
index = json.loads(index_path.read_text())
selection = json.loads(selection_path.read_text())
repeats = json.loads(repeat_path.read_text())
assert repeats["selection_sha256"] == digest(selection_path)
assert args.allow_partial or repeats["status"] == "complete"
groups = {}
for number, group in enumerate(selection["groups"], 1):
    key = tuple(group[k] for k in ("before", "after", "suite", "mode"))
    assert key not in groups
    runs = [row for row in repeats["runs"] if row["group"] == number]
    values = {}
    for row in runs:
        if row["status"] != "passed":
            continue
        report = repeat_path.parent / (row["label"] + ".json")
        log = repeat_path.parent / (row["label"] + ".log")
        assert digest(report) == row["report_sha256"]
        assert digest(log) == row["log_sha256"]
        values[row["repeat"], row["role"]] = means(report)
        assert sorted(values[row["repeat"], row["role"]]) == sorted(group["queries"])
    complete = len(values) == 4
    groups[key] = {
        "number": number,
        "complete": complete,
        "ratios": {
            query: [values[n, "after"][query] / values[n, "before"][query] for n in (1, 2)]
            for query in group["queries"]
        } if complete else {},
    }
rows = []
comparisons = []
for comparison in index["comparisons"]:
    key = tuple(comparison[k] for k in ("before", "after", "suite", "mode"))
    group = groups.get(key)
    first_path = Path(comparison["report"])
    first = json.loads(first_path.read_text())
    flagged = comparison["flags_above_10_percent"]
    bad = []
    for item in first["rows"]:
        query = item["query"]
        pair = group["ratios"].get(query, []) if group else []
        if len(pair) == 2:
            status = "repeatable_regression" if all(value > 1.10 for value in pair) else "not_repeatable"
            if status == "repeatable_regression":
                bad.append(query)
        elif query in flagged:
            status = "pending_repeat"
        else:
            status = "not_flagged_first_pass"
        rows.append({**dict(zip(("before", "after", "suite", "mode"), key)),
                     "query": query, "first_after_over_before": item["after_over_before"],
                     "repeat_1_after_over_before": pair[0] if pair else "",
                     "repeat_2_after_over_before": pair[1] if pair else "", "status": status})
    comparisons.append({**comparison, "first_report_sha256": digest(first_path),
                        "repeat_group": group["number"] if group else None,
                        "repeatable_regressions": bad,
                        "acceptance": "blocked_by_repeatable_regression" if bad else
                        "pending_repeat" if flagged and (not group or not group["complete"]) else
                        "passed_performance_gate"})
args.output.mkdir(exist_ok=False)
with (args.output / "queries.csv").open("x", newline="") as target:
    writer = csv.DictWriter(target, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
result = {"repeat_status": repeats["status"], "rule": selection["rule"],
          "first_index_sha256": digest(index_path), "repeat_plan_sha256": digest(repeat_path),
          "comparisons": comparisons,
          "completed_repeat_groups": sum(group["complete"] for group in groups.values()),
          "total_repeat_groups": len(groups),
          "repeat_golden_checks": sum(len(row["queries"]) for row in repeats["runs"] if row["status"] == "passed"),
          "limits": ["First-pass suite geometric means are retained unchanged.",
                     "All new first-pass flags and predeclared historical targets receive paired repeats; both ratios above 1.10 block acceptance even without a first-pass flag.",
                     "Comparisons of prerequisite-only cohorts are contextual, not independently submitted changes."]}
(args.output / "acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("comparisons", "limits")}))
