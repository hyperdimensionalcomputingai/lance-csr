"""Prepare focused CSR acceptance cells; measurements require explicit quiescence."""

import argparse
import ast
import hashlib
import importlib.util
import json
import os
import platform
import resource
import subprocess
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path("/private/tmp/lance-csr-submissions")
BENCH = Path("/private/tmp/lance-csr-benchmark-ic")
ATTRIBUTION = "Submitted by David Hughes (@stugorf), with AI Collaboration."
COHORTS = {
    "main": (
        "/private/tmp/lance-csr-baseline",
        ROOT / "wheels/main-cp313/release-proof.json",
    ),
    "11": (
        "/private/tmp/lance-csr-issue-11",
        ROOT / "wheels/issue-11-clean-r2/release-proof.json",
    ),
    "13": (
        "/private/tmp/lance-csr-issue-13",
        ROOT / "wheels/issue-13/release-proof.json",
    ),
    "16": (
        "/private/tmp/lance-csr-issue-16",
        ROOT / "wheels/issue-16/release-proof.json",
    ),
    "17": (
        "/private/tmp/lance-csr-issue-17",
        ROOT / "wheels/issue-17/release-proof.json",
    ),
}
PARAMS = {
    "9": {"personId": 1131, "maxDate": "2010-11-16T12:00:00+00:00"},
    "12": {"personId": 1131, "tagClassName": "Monarch"},
    "13": {"person1Id": 1131, "person2Id": 19791209300775},
    "14": {"person1Id": 1131, "person2Id": 19791209300775},
}


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def manifests(root):
    files = sorted(Path(root).glob("*.lance/_versions/*.manifest"))
    assert files, root
    return {str(path.relative_to(root)): digest(path) for path in files}


def git(source, *args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True).strip()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def query_text(number):
    tree = ast.parse((BENCH / "lance_csr/query.py").read_text())
    if number == "14":
        item = next(
            n
            for n in tree.body
            if isinstance(n, ast.Assign) and n.targets[0].id == "PORTS"
        )
        return ast.literal_eval(item.value)[14]
    function = next(
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name == f"run_query{number}"
    )
    return next(
        n.value.value
        for n in function.body
        if isinstance(n, ast.Assign) and n.targets[0].id == "query"
    )


def physical(plan):
    return plan[plan.index("physical_plan") :]


def plan_metrics(plan):
    text = physical(plan)
    return {
        "csr_expands": text.count("CsrExpandExec"),
        "unions": text.count("UnionExec"),
        "physical_plan_bytes": len(text.encode()),
        "physical_plan_lines": len(text.splitlines()),
    }


def prepare(output, python, final_source=None, final_proof=None):
    if final_source or final_proof:
        assert final_source and final_proof
        proof = json.loads(final_proof.read_text())
        assert proof.get("profile") == "release", (
            "Final cohort must be an optimized release"
        )
        assert "3.13" in proof.get("build_python", ""), (
            "Matched CPython 3.13 build metadata required"
        )
        assert proof.get("installed_extension_matches_archive") is True, (
            "Qualified wheel consumer proof required"
        )
        COHORTS["final"] = (str(final_source), final_proof)
    output.mkdir(parents=True, exist_ok=False)
    cohorts = {}
    for name, (source, proof_path) in COHORTS.items():
        proof = json.loads(proof_path.read_text())
        assert proof.get("profile") == "release", "Unqualified build profile"
        commit = proof.get("source_commit", proof.get("source_revision"))
        wheel = Path(proof.get("wheel_path", proof.get("wheel")))
        assert git(source, "rev-parse", "HEAD") == commit
        assert not git(source, "status", "--porcelain")
        assert digest(wheel) == proof["wheel_sha256"]
        unpacked = output / "wheels" / name
        with zipfile.ZipFile(wheel) as archive:
            archive.extractall(unpacked)
        extension = next((unpacked / "lance_csr").glob("_internal*.so"))
        assert digest(extension) == proof["extension_sha256"]
        cohorts[name] = {
            "source": source,
            "commit": commit,
            "proof": str(proof_path),
            "proof_sha256": digest(proof_path),
            "wheel": str(wheel),
            "wheel_sha256": digest(wheel),
            "extension_sha256": digest(extension),
            "unpacked": str(unpacked),
            "cargo_lock_sha256": digest(Path(source) / "Cargo.lock"),
        }
    data = {
        str(n): str(ROOT / f"hub-wide-fixtures-r1/rows-{n}")
        for n in (100_000, 500_000, 1_000_000)
    }
    data["sf1"] = str(BENCH / "lance_csr/graph_lance")
    inputs = {
        name: {"path": path, "manifests": manifests(Path(path))}
        for name, path in data.items()
    }
    queries = {
        n: {
            "text": query_text(n),
            "params": PARAMS[n],
            "expected": str(BENCH / f"expected/ic{n}.json"),
            "expected_sha256": digest(BENCH / f"expected/ic{n}.json"),
        }
        for n in PARAMS
    }
    cells = []

    def add(kind, names, **values):
        names = [name for name in names if name in cohorts]
        for repeat in range(3):
            # Rotate source order across repetitions; each cell gets a fresh process.
            order = names[repeat % len(names) :] + names[: repeat % len(names)]
            for cohort in order:
                label = "-".join(
                    [kind, *[str(v) for v in values.values()], cohort, f"r{repeat + 1}"]
                )
                cells.append(
                    {
                        "label": label,
                        "kind": kind,
                        "cohort": cohort,
                        "repeat": repeat + 1,
                        **values,
                    }
                )

    for rows in (100_000, 500_000, 1_000_000):
        add("hub", ["main", "11", "final"], rows=rows)
    for shape in ("homogeneous", "mixed"):
        for hops in (2, 5, 10, 20):
            add("plan", ["main", "11", "13", "final"], shape=shape, hops=hops)
    for number, names in [
        ("9", ["main", "13", "16", "final"]),
        ("12", ["main", "11", "13", "final"]),
        ("13", ["main", "11", "17", "final"]),
        ("14", ["main", "11", "17", "final"]),
    ]:
        add("sf1", names, query=number)
    plan = {
        "status": "prepared_only",
        "attribution": ATTRIBUTION,
        "harness": str(Path(__file__).resolve()),
        "harness_sha256": digest(__file__),
        "python": str(python.absolute()),
        "python_version": subprocess.check_output(
            [str(python), "--version"], text=True
        ).strip(),
        "platform": platform.platform(),
        "cohorts": cohorts,
        "inputs": inputs,
        "queries": queries,
        "benchmark_source": str(BENCH),
        "benchmark_commit": git(BENCH, "rev-parse", "HEAD"),
        "benchmark_files": {
            str(BENCH / p): digest(BENCH / p)
            for p in ("lance_csr/query.py", "conftest.py")
        },
        "cells": cells,
        "limits": {"wall_seconds_per_cell": 600, "rss_bytes_per_cell": 10_000_000_000},
        "timing_status": "No measurements run during preparation; explicit coordinator quiescence required.",
    }
    save(output / "plan.json", plan)
    save(output / "freeze.json", {"plan_sha256": digest(output / "plan.json")})
    print(
        json.dumps(
            {
                "plan": str(output / "plan.json"),
                "cells": len(cells),
                "status": "prepared_only",
            }
        )
    )


def rss(pid=None):
    return (
        int(
            subprocess.check_output(["ps", "-o", "rss=", "-p", str(pid or os.getpid())])
        )
        * 1024
    )


def peak_rss():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return value if sys.platform == "darwin" else value * 1024


def activate(plan, cohort):
    selected = plan["cohorts"][cohort]
    sys.path.insert(0, selected["unpacked"])
    from lance_csr import _internal

    assert digest(_internal.__file__) == selected["extension_sha256"]
    return selected


def tiny_graph(mixed=False):
    import pyarrow as pa
    from lance_csr import CypherEngine, GraphConfig

    if mixed:
        config = (
            GraphConfig.builder()
            .node_table("Tag", "id")
            .node_table("Tagclass", "id")
            .rel_table("hasType", "Tag", "Tagclass", "src", "dst")
            .rel_table("isSubclassOf", "Tagclass", "Tagclass", "src", "dst")
            .build()
        )
        tables = {
            "Tag": pa.table({"id": [0]}),
            "Tagclass": pa.table({"id": range(1, 21)}),
            "hasType": pa.table({"src": [0], "dst": [1]}),
            "isSubclassOf": pa.table({"src": range(1, 20), "dst": range(2, 21)}),
        }
        query = "MATCH (a:Tag {id: 0})-[:hasType|isSubclassOf*1..HOPS]->(b:Tagclass) RETURN b.id AS id"
    else:
        config = (
            GraphConfig.builder()
            .node_table("Person", "id")
            .rel_table("KNOWS", "Person", "Person", "src", "dst")
            .build()
        )
        tables = {
            "Person": pa.table({"id": range(21)}),
            "KNOWS": pa.table({"src": range(20), "dst": range(1, 21)}),
        }
        query = (
            "MATCH (a:Person {id: 0})-[:KNOWS*1..HOPS]->(b:Person) RETURN b.id AS id"
        )
    return CypherEngine(config, tables, use_csr=True), query


def smoke(plan, cohort):
    activate(plan, cohort)
    for mixed in (False, True):
        engine, text = tiny_graph(mixed)
        query = text.replace("HOPS", "2")
        assert sorted(row["id"] for row in engine.execute(query).to_pylist()) == [1, 2]
        metrics = plan_metrics(engine.explain(query))
        if cohort in ("13", "16", "final"):
            assert metrics["csr_expands"] == 1 and metrics["unions"] == 0, metrics
    print(
        json.dumps(
            {
                "cohort": cohort,
                "status": "untimed_smoke_passed",
                "attribution": ATTRIBUTION,
            }
        )
    )


def worker(plan_path, label, output):
    plan = json.loads(plan_path.read_text())
    assert (
        digest(plan_path)
        == json.loads((plan_path.parent / "freeze.json").read_text())["plan_sha256"]
    )
    assert digest(__file__) == plan["harness_sha256"]
    cell = next(c for c in plan["cells"] if c["label"] == label)
    selected = activate(plan, cell["cohort"])
    import lance
    import pyarrow as pa
    from lance_csr import CypherEngine, GraphConfig

    result = {
        "cell": cell,
        "source_commit": selected["commit"],
        "wheel_sha256": selected["wheel_sha256"],
        "extension_sha256": selected["extension_sha256"],
        "python": sys.version,
        "lance": lance.__version__,
        "pyarrow": pa.__version__,
        "status": "passed",
    }
    if cell["kind"] == "hub":
        import numpy as np
        import pyarrow.compute as pc

        rows = cell["rows"]
        data = plan["inputs"][str(rows)]
        assert manifests(Path(data["path"])) == data["manifests"]
        people = lance.dataset(Path(data["path"]) / "person.lance")
        edges = lance.dataset(Path(data["path"]) / "knows.lance")
        assert people.count_rows() == edges.count_rows() == rows
        assert people.schema == pa.schema(
            [("id", pa.int64()), ("payload", pa.binary(4096))]
        )
        config = (
            GraphConfig.builder()
            .node_table("Person", "id")
            .rel_table("KNOWS", "Person", "Person", "src", "dst")
            .build()
        )
        engine = CypherEngine(config, {"Person": people, "KNOWS": edges}, use_csr=True)
        query = "MATCH (a:Person {id: 0})-[:KNOWS]->(b:Person) RETURN b.id AS id, b.payload AS payload"
        pre = {"rss_bytes": rss(), "peak_rss_bytes": peak_rss()}
        save(output / "pre-query.json", pre)
        started = time.perf_counter()
        reader = engine.execute_batches(query)
        count = batches = checksum = largest = 0
        first = None
        samples = {}
        wanted = {0, rows // 2, rows - 1}
        for batch in reader:
            if batch.num_rows and first is None:
                first = time.perf_counter() - started
            ids, payload = batch.column(0), batch.column(1)
            assert ids.type == pa.int64() and ids.null_count == 0
            assert payload.type == pa.binary(4096) and payload.null_count == 0
            values = ids.to_numpy(zero_copy_only=False)
            assert np.array_equal(values, np.arange(count, count + batch.num_rows)), (
                "Missing/duplicate/out-of-order hub neighbors"
            )
            for value in wanted:
                if count <= value < count + batch.num_rows:
                    samples[value] = payload[value - count].as_py()
            count += batch.num_rows
            checksum += pc.sum(ids).as_py() or 0
            batches += 1
            largest = max(largest, batch.num_rows)
            if cell["cohort"] != "main":
                assert batch.num_rows <= 8192, (
                    "CSR output exceeded default bounded chunk"
                )
            del batch, ids, payload, values
        elapsed = time.perf_counter() - started
        end_peak, end_rss = peak_rss(), rss()
        save(
            output / "post-query.json",
            {"rss_bytes": end_rss, "peak_rss_bytes": end_peak},
        )
        reader.close()
        assert (
            count == rows and checksum == rows * (rows - 1) // 2 and first is not None
        )
        expected = {
            row["id"]: row["payload"] for row in people.take(sorted(wanted)).to_pylist()
        }
        assert samples == expected
        assert manifests(Path(data["path"])) == data["manifests"]
        result.update(
            output_rows=count,
            checksum=checksum,
            batches=batches,
            maximum_batch_rows=largest,
            query_first_batch_seconds=first,
            query_seconds_including_validation=elapsed,
            pre_query=pre,
            post_query_rss_bytes=end_rss,
            process_peak_rss_bytes=end_peak,
            query_high_water_growth_lower_bound_bytes=max(
                0, end_peak - pre["peak_rss_bytes"]
            ),
            payload_samples_sha256={
                str(k): hashlib.sha256(v).hexdigest() for k, v in samples.items()
            },
        )
    elif cell["kind"] == "plan":
        engine, query = tiny_graph(cell["shape"] == "mixed")
        query = query.replace("HOPS", str(cell["hops"]))
        started = time.perf_counter()
        explained = engine.explain(query)
        result["explain_seconds_including_formatting"] = time.perf_counter() - started
        result.update(plan_metrics(explained))
        (output / "explain.txt").write_text(explained)
        got = sorted(row["id"] for row in engine.execute(query).to_pylist())
        assert got == list(range(1, cell["hops"] + 1))
        if cell["cohort"] in ("13", "final"):
            assert result["csr_expands"] == 1 and result["unions"] == 0
        result["verified_node_ids"] = got
    else:
        data = plan["inputs"]["sf1"]
        assert manifests(Path(data["path"])) == data["manifests"]
        for path, checksum in plan["benchmark_files"].items():
            assert digest(path) == checksum
        os.environ["LANCE_CSR_MODE"] = "lazy"
        os.environ.pop("WRITE_GOLDEN", None)
        module = load_module("focused_ic_queries", BENCH / "lance_csr/query.py")
        canonical = load_module(
            "focused_ic_checks", BENCH / "conftest.py"
        ).canonical_rows
        query = plan["queries"][cell["query"]]
        assert digest(query["expected"]) == query["expected_sha256"]
        params = dict(query["params"])
        if "maxDate" in params:
            params["maxDate"] = datetime.fromisoformat(params["maxDate"])
        engine = module.engine()
        started = time.perf_counter()
        rows = engine.execute(query["text"], params).to_pylist()
        result["execute_and_convert_seconds"] = time.perf_counter() - started
        got = canonical(rows)
        expected = [
            {k.lower(): v for k, v in row.items()}
            for row in json.loads(Path(query["expected"]).read_text())
        ]
        if cell["query"] == "14":
            got, expected = [
                sorted(value, key=lambda row: json.dumps(row, sort_keys=True))
                for value in (got, expected)
            ]
        assert got == expected, "Immutable SF1 golden mismatch"
        encoded = json.dumps(got, sort_keys=True).encode()
        (output / "canonical.json").write_bytes(encoded)
        result.update(
            output_rows=len(rows),
            result_sha256=hashlib.sha256(encoded).hexdigest(),
            query_sha256=hashlib.sha256(query["text"].encode()).hexdigest(),
        )
        assert manifests(Path(data["path"])) == data["manifests"]
    save(output / "result.json", result)


def execute(plan_path, label):
    plan = json.loads(plan_path.read_text())
    assert (
        digest(plan_path)
        == json.loads((plan_path.parent / "freeze.json").read_text())["plan_sha256"]
    )
    assert digest(__file__) == plan["harness_sha256"]
    cell = next(c for c in plan["cells"] if c["label"] == label)
    selected = plan["cohorts"][cell["cohort"]]
    assert digest(selected["wheel"]) == selected["wheel_sha256"]
    output = plan_path.parent / "results" / label
    output.mkdir(parents=True, exist_ok=False)
    command = [
        plan["python"],
        "-I",
        __file__,
        "worker",
        "--plan",
        str(plan_path),
        "--cell",
        label,
        "--output",
        str(output),
    ]
    observed_peak = samples = 0
    outcome = "completed"
    started = time.monotonic()
    with (output / "raw.log").open("x") as log:
        process = subprocess.Popen(
            command,
            stdout=log,
            stderr=subprocess.STDOUT,
            env=os.environ | {"PYTHONDONTWRITEBYTECODE": "1"},
        )
        while process.poll() is None:
            try:
                current = rss(process.pid)
            except (ValueError, subprocess.CalledProcessError):
                current = 0
            if (output / "pre-query.json").exists() and not (
                output / "post-query.json"
            ).exists():
                observed_peak = max(observed_peak, current)
                samples += 1
            if time.monotonic() - started > plan["limits"]["wall_seconds_per_cell"]:
                outcome = "wall_limit"
            if current > plan["limits"]["rss_bytes_per_cell"]:
                outcome = "rss_limit"
            if outcome != "completed":
                process.kill()
                break
            time.sleep(0.05)
        code = process.wait()
    record = {
        "cell": cell,
        "command": command,
        "exit_code": code,
        "outcome": outcome,
        "plan_sha256": digest(plan_path),
        "harness_sha256": digest(__file__),
        "status": "passed"
        if code == 0 and outcome == "completed"
        else "failed_or_unverified",
        "sampler_interval_seconds": 0.05,
        "query_rss_samples": samples,
        "sampled_query_peak_rss_bytes": observed_peak or None,
        "attribution": ATTRIBUTION,
    }
    if samples:
        before = json.loads((output / "pre-query.json").read_text())
        record["sampled_query_rss_growth_lower_bound_bytes"] = max(
            0, observed_peak - before["rss_bytes"]
        )
    save(output / "process.json", record)
    print(json.dumps(record))
    if record["status"] != "passed":
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "smoke", "execute", "worker"])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--python", type=Path)
    parser.add_argument("--final-source", type=Path)
    parser.add_argument("--final-proof", type=Path)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--cell")
    parser.add_argument("--cohort")
    parser.add_argument("--quiescent-confirmed", action="store_true")
    args = parser.parse_args()
    if args.action == "prepare":
        if not args.output or not args.python:
            parser.error("prepare requires --output and --python")
        prepare(args.output.resolve(), args.python, args.final_source, args.final_proof)
    elif args.action == "smoke":
        smoke(json.loads(args.plan.read_text()), args.cohort)
    elif args.action == "worker":
        worker(args.plan.resolve(), args.cell, args.output)
    else:
        if not args.quiescent_confirmed:
            parser.error(
                "Measurements require explicit coordinator quiescence confirmation"
            )
        execute(args.plan.resolve(), args.cell)


if __name__ == "__main__":
    main()
