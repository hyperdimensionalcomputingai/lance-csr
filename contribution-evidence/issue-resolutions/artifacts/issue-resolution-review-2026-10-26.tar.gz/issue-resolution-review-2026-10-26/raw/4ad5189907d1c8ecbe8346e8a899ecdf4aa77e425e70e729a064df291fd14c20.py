"""Qualify one bounded-work scheduling experiment against fixed main/owner bases."""
import json
import subprocess
from pathlib import Path
import run_release_comparisons as common
root=Path(__file__).resolve().parent
out=root/'combined-budget-finish-r1';out.mkdir(exist_ok=False)
phase='candidate-budget-release'
proof=root/f'wheels/{phase}/release-proof.json';assert proof.is_file()
mandatory=[]
for mode in ('memory','lazy'):
    for before in ('main-cp313','candidate-final-release'):
        mandatory += [dict(before=before,after=phase,suite='q30',mode=mode,queries=[30]),dict(before=before,after=phase,suite='ic',mode=mode,queries=[3,6,9,13])]
rule='Both complete suites/modes first; every predeclared historical target and every new primary flag gets two fresh forward/reversed pairs. Both ratios above1.10 block acceptance, even without a first-pass flag. No optional stopping.'
protocol=dict(runner_sha256=common.digest(__file__),mandatory_groups=mandatory,rule=rule,context_only=['candidate-bfbbb24'])
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
state={'status':'running','protocol_sha256':common.digest(out/'protocol.json'),'runs':[]}
def save():(out/'manifest.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,command):
    common.check_builds_stopped()
    with (out/(label+'.log')).open('x') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    state['runs'].append(dict(label=label,command=command,returncode=result.returncode,log_sha256=common.digest(out/(label+'.log'))))
    if result.returncode:state['status']='failed_or_unverified'
    save();assert result.returncode==0,label
    print(label,'passed',flush=True)
proofs=out/'proof-list.json';proofs.write_text(json.dumps([str(proof)])+'\n');save()
run('complete-suites',['python3',str(root/'run_release_comparisons.py'),str(proofs),str(root/'acceptance-combined-budget-r1'),'--execute','--quiescent-confirmed'])
manifest=root/'frozen-acceptance-combined-r10/manifest.json'
run('combine',['python3',str(root/'combine_frozen_acceptance.py'),str(root/'frozen-acceptance-combined-r9/manifest.json'),str(root/'acceptance-combined-budget-r1/manifest.json'),str(manifest.parent)])
tables=root/'combined-budget-comparison-tables-r1';tables.mkdir(exist_ok=False);comparisons=[]
for before in ['main-cp313','candidate-final-release','candidate-bfbbb24']:
 for suite in ('q30','ic'):
  for mode in ('memory','lazy'):
   target=tables/f'{phase}-vs-{before}-{suite}-{mode}'
   run(target.name,['python3',str(root/'compare_release_cells_r3.py'),str(manifest),f'{before}-{suite}-{mode}',f'{phase}-{suite}-{mode}',str(target)])
   value=json.loads(target.with_suffix('.json').read_text());comparisons.append(dict(before=before,after=phase,suite=suite,mode=mode,speedup=value['geometric_mean_speedup'],flags_above_10_percent=value['investigate_above_10_percent'],report=str(target.with_suffix('.json')),primary=before!='candidate-bfbbb24'))
(tables/'index.json').write_text(json.dumps(dict(comparisons=comparisons,status='first_pass_only'),indent=2)+'\n')
groups=[]
for c in comparisons:
 if not c['primary']:continue
 keys=('before','after','suite','mode');key=tuple(c[k] for k in keys);queries=set(c['flags_above_10_percent'])
 for m in mandatory:
  if tuple(m[k] for k in keys)==key:queries.update(m['queries'])
 if queries:groups.append({k:c[k] for k in keys}|dict(queries=sorted(queries)))
assert len(groups)==8
selection=root/'combined-budget-repeat-selection-r1.json';selection.write_text(json.dumps(dict(rule=rule,groups=groups),indent=2)+'\n')
run('primary-repeats',['python3',str(root/'repeat_frozen_flags.py'),str(manifest),str(selection),str(root/'combined-budget-primary-repeats-r1')])
state['status']='complete';save()
