"""Run nonshipping IC9 diagnostics in a fresh process; never write goldens."""

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
BENCH = Path("/private/tmp/lance-csr-benchmark-ic")
PREFIX = "LANCE_CSR_DIAGNOSTIC "


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def execute(args):
    assert args.mode == "smoke" or args.quiescent_confirmed
    manifest = json.loads((HERE / "instrumentation.json").read_text())
    selected = manifest["cohorts"][args.cohort]
    source = Path(selected["source"])
    assert (
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source, text=True
        ).strip()
        == selected["commit"]
    )
    assert not subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=source, text=True
    )
    qualification = json.loads(args.proof.read_text())
    assert qualification["source_commit"] == selected["commit"]
    assert qualification["profile"] == "debug"
    assert qualification["diagnostic_only"] is True
    wheel = Path(qualification["wheel_path"])
    assert sha(wheel) == qualification["wheel_sha256"]
    args.output.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(wheel) as archive:
        archive.extractall(args.output / "wheel")
    (extension,) = (args.output / "wheel/lance_csr").glob("_internal*.so")
    assert sha(extension) == qualification["extension_sha256"]
    command = [
        sys.executable,
        "-I",
        str(Path(__file__).resolve()),
        "worker",
        "--mode",
        args.mode,
        "--output",
        str(args.output),
    ]
    save(
        args.output / "provenance.json",
        {
            "command": command,
            "source_commit": selected["commit"],
            "base_commit": selected["base"],
            "runner_sha256": sha(__file__),
            "instrumentation_sha256": sha(HERE / "instrumentation.json"),
            "wheel_sha256": sha(wheel),
            "extension_sha256": sha(extension),
            "qualification_path": str(args.proof),
            "qualification_sha256": sha(args.proof),
            "python": sys.version,
            "mode": args.mode,
            "performance_claim": "None: debug instrumented operations are diagnostic only.",
        },
    )
    with (args.output / "raw.log").open("x") as raw:
        try:
            result = subprocess.run(
                command,
                stdout=raw,
                stderr=subprocess.STDOUT,
                env=os.environ
                | {"LANCE_CSR_DIAGNOSTIC_TAKES": "1", "PYTHONDONTWRITEBYTECODE": "1"},
                timeout=600,
                check=False,
            )
        except subprocess.TimeoutExpired:
            save(
                args.output / "process.json",
                {
                    "status": "failed_or_unverified",
                    "outcome": "wall_limit",
                    "wall_limit_seconds": 600,
                    "exit_code": None,
                },
            )
            raise SystemExit(
                "Diagnostic exceeded 600 seconds; raw output preserved"
            ) from None
    records = [
        json.loads(line[len(PREFIX) :])
        for line in (args.output / "raw.log").read_text().splitlines()
        if line.startswith(PREFIX)
    ]
    save(args.output / "records.json", records)
    save(
        args.output / "process.json",
        {
            "exit_code": result.returncode,
            "status": "passed" if result.returncode == 0 else "failed_or_unverified",
        },
    )
    if result.returncode:
        raise SystemExit(result.returncode)
    assert records, "Compiled wheel did not emit instrumentation"
    assert not any(r["event"] == "diagnostic_error" for r in records)
    assert all(r.get("success", True) for r in records)
    takes = [
        r for r in records if r["event"] == "node_rows_take" and r["fetch_invoked"]
    ]
    by_column = Counter()
    for take in takes:
        for column in take["columns"]:
            by_column[(take["backend"], take["dataset"], column)] += take[
                "row_occurrences"
            ]
    summary = {
        "actual_fetch_requests": len(takes),
        "requested_row_occurrences_across_fetches": sum(
            r["row_occurrences"] for r in takes
        ),
        "requested_cells": sum(r["row_occurrences"] * len(r["columns"]) for r in takes),
        "cells_by_column": [
            {"backend": k[0], "dataset": k[1], "column": k[2], "cells": v}
            for k, v in sorted(by_column.items())
        ],
        "take_operation_wall_ns_sum": sum(r["operation_wall_ns"] for r in takes),
        "materialization_wall_ns_sum_including_nested_logging": sum(
            r["operation_wall_ns_including_nested_logging"]
            for r in records
            if r["event"] == "materialize"
        ),
        "decode_time": "unverified: not separately exposed",
        "physical_disk_reads": "unverified: object-store counters are not physical disk counters",
        "wall_interpretation": "Overlapping async durations and nested logging; sums are not query latency or pure I/O time.",
    }
    if args.mode == "ic9":
        snapshots = {
            stage: {
                r["store_identity"]: r
                for r in records
                if r["event"] == "primary_store_snapshot" and r["stage"] == stage
            }
            for stage in ["before", "after"]
        }
        before, after = snapshots["before"], snapshots["after"]
        assert before and before.keys() == after.keys()
        deltas = []
        for identity, first in before.items():
            last = after[identity]
            assert (
                last["read_iops"] >= first["read_iops"]
                and last["read_bytes"] >= first["read_bytes"]
            )
            deltas.append(
                {
                    "store_identity": identity,
                    "read_requests": last["read_iops"] - first["read_iops"],
                    "read_bytes": last["read_bytes"] - first["read_bytes"],
                }
            )
        summary["primary_store_deltas"] = deltas
        summary["primary_store_read_requests"] = sum(d["read_requests"] for d in deltas)
        summary["primary_store_read_bytes"] = sum(d["read_bytes"] for d in deltas)
    save(args.output / "summary.json", summary)
    print(json.dumps(summary))


def worker(args):
    sys.path.insert(0, str(args.output / "wheel"))
    import lance
    import pyarrow as pa
    from lance_csr import CypherEngine, GraphConfig, _internal

    assert Path(_internal.__file__).resolve().is_relative_to(args.output / "wheel")
    if args.mode == "smoke":
        config = (
            GraphConfig.builder()
            .node_table("Person", "id")
            .rel_table("KNOWS", "Person", "Person", "src", "dst")
            .build()
        )
        people = pa.table({"id": [0, 1, 2], "age": [0, 8, 9], "name": ["a", "b", "c"]})
        edges = pa.table({"src": [0, 0, 0], "dst": [1, 1, 2]})
        disk = args.output / "fixture"
        datasets = {
            "Person": lance.write_dataset(people, disk / "person.lance"),
            "KNOWS": lance.write_dataset(edges, disk / "knows.lance"),
        }
        engine = CypherEngine(config, datasets, use_csr=True)
        actual = engine.execute(
            "MATCH (a:Person {id: 0})-[:KNOWS]->(b:Person) WHERE b.age >= 8 RETURN b.id AS id, b.age AS age, b.name AS name"
        ).to_pylist()
        assert actual == [{"id": 1, "age": 8, "name": "b"}] * 2 + [
            {"id": 2, "age": 9, "name": "c"}
        ]
    else:
        import ast

        source = BENCH / "lance_csr/query.py"
        expected_path = BENCH / "expected/ic9.json"
        tree = ast.parse(source.read_text())
        function = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "run_query9"
        )
        query = next(
            n.value.value
            for n in function.body
            if isinstance(n, ast.Assign) and n.targets[0].id == "query"
        )
        manifests = {
            str(p.relative_to(BENCH)): sha(p)
            for p in sorted(
                (BENCH / "lance_csr/graph_lance").glob("*.lance/_versions/*.manifest")
            )
        }
        assert manifests
        save(
            args.output / "inputs.json",
            {
                "benchmark_commit": subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=BENCH, text=True
                ).strip(),
                "source_sha256": sha(source),
                "canonical_helper_sha256": sha(BENCH / "conftest.py"),
                "query": query,
                "query_sha256": hashlib.sha256(query.encode()).hexdigest(),
                "params": {"personId": 1131, "maxDate": "2010-11-16T12:00:00+00:00"},
                "expected_sha256": sha(expected_path),
                "manifests": manifests,
            },
        )
        assert json.loads((args.output / "inputs.json").read_text()) == json.loads(
            (HERE / "frozen-inputs.json").read_text()
        ), "Frozen SF1 inputs changed"
        os.environ["LANCE_CSR_MODE"] = "lazy"
        os.environ.pop("WRITE_GOLDEN", None)
        queries = module("ic9_diagnostic_queries", source)
        canonical = module(
            "ic9_diagnostic_canonical", BENCH / "conftest.py"
        ).canonical_rows
        engine = queries.engine()
        actual = canonical(
            engine.execute(
                query,
                {
                    "personId": 1131,
                    "maxDate": datetime.fromisoformat("2010-11-16T12:00:00+00:00"),
                },
            ).to_pylist()
        )
        expected = [
            {k.lower(): v for k, v in row.items()}
            for row in json.loads(expected_path.read_text())
        ]
        assert actual == expected, "Immutable IC9 golden mismatch"
        assert manifests == {
            str(p.relative_to(BENCH)): sha(p)
            for p in sorted(
                (BENCH / "lance_csr/graph_lance").glob("*.lance/_versions/*.manifest")
            )
        }
    save(
        args.output / "result.json",
        {
            "status": "passed",
            "rows": actual,
            "pyarrow": pa.__version__,
            "lance": lance.__version__,
        },
    )


def main():
    for name, expected in json.loads((HERE / "freeze.json").read_text()).items():
        assert sha(HERE / name) == expected, f"Frozen diagnostic file changed: {name}"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["execute", "worker"])
    parser.add_argument("--mode", choices=["smoke", "ic9"], required=True)
    parser.add_argument("--cohort", choices=["main", "issue-16"])
    parser.add_argument("--proof", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--quiescent-confirmed", action="store_true")
    args = parser.parse_args()
    args.output = args.output.resolve()
    if args.action == "worker":
        worker(args)
    else:
        execute(args)


if __name__ == "__main__":
    main()
