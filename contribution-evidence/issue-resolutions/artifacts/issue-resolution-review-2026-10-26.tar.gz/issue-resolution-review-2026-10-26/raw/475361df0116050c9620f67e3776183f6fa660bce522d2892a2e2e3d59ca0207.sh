#!/bin/zsh
set -euo pipefail
phase="$1"
checkout="$2"
target="$3"
logs=/private/tmp/lance-csr-runtime
runtime=/private/tmp/lance-csr-issue-20-math/python/.venv
export PATH=/private/tmp/lance-csr-runtime/cargo/bin:$runtime/bin:$PATH
export CARGO_HOME=/private/tmp/lance-csr-runtime/cargo
export RUSTUP_HOME=/private/tmp/lance-csr-runtime/rustup
export CARGO_TARGET_DIR="$target"
export CARGO_BUILD_JOBS=2
export VIRTUAL_ENV="$runtime"
export UV_CACHE_DIR=/private/tmp/lance-csr-uv-cache
cd "$checkout"
git diff --exit-code > "$logs/$phase-clean-source.log"
git rev-parse HEAD > "$logs/$phase-source.txt"
cargo fmt --all --check > "$logs/$phase-format.log" 2>&1
cargo test --workspace --locked > "$logs/$phase-rust-workspace.log" 2>&1
cargo clippy --workspace --all-targets --locked -- -D warnings > "$logs/$phase-clippy.log" 2>&1
cd python
maturin develop --skip-install > "$logs/$phase-python-build.log" 2>&1
export PYTHONPATH="$checkout/python/python"
python -m pytest python/tests -q > "$logs/$phase-python-all.log" 2>&1
ruff check python > "$logs/$phase-ruff.log" 2>&1
ruff format --check python >> "$logs/$phase-ruff.log" 2>&1
pyright --pythonpath /private/tmp/lance-csr-issue-22/python/.venv/bin/python > "$logs/$phase-pyright.log" 2>&1
python ../docs/check_snippets.py > "$logs/$phase-snippets.log" 2>&1
cd ..
uv run --project docs --locked zensical build --strict > "$logs/$phase-docs.log" 2>&1
UV_CACHE_DIR=/Users/davidhughes/.cache/uv uvx typos@1.26.0 . > "$logs/$phase-typos.log" 2>&1
printf '%s validation complete\n' "$phase"
