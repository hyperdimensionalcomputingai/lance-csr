"""Supporting release-wheel deadline/CPU/overhead observations; run without builds."""
import argparse
import hashlib
import json
import math
import platform
import resource
import statistics
import time
from pathlib import Path

import pyarrow as pa
from lance_csr import CypherEngine, GraphConfig, _internal

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('proof', type=Path)
parser.add_argument('--repetitions', type=int, default=3)
parser.add_argument('--overhead-pairs', type=int, default=100)
args = parser.parse_args()
assert args.repetitions > 0 and args.overhead_pairs > 1
proof = json.loads(args.proof.read_text())
assert proof['profile'] == 'release'
module = Path(_internal.__file__).resolve()
with module.open('rb') as src:
    module_hash = hashlib.file_digest(src, 'sha256').hexdigest()
assert module_hash == proof['extension_sha256'], (module, module_hash)
config = GraphConfig.builder().node_table('Person', 'id').build()
engine = CypherEngine(config, {'Person': pa.table({'id': list(range(20_000))})})
query = ('UNWIND [30000,30001] AS minimum CALL { WITH minimum '
         'MATCH (a:Person), (b:Person), (c:Person) '
         'WHERE a.id + b.id + c.id > minimum RETURN count(*) AS n } RETURN n')
normal = 'MATCH (p:Person) WHERE p.id >= 19990 RETURN p.id AS id ORDER BY id'
expected = [{'id': value} for value in range(19990, 20000)]
assert engine.execute(normal).to_pylist() == expected

def cpu():
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return usage.ru_utime + usage.ru_stime

observations = []
for _ in range(args.repetitions):
    start = time.monotonic()
    try:
        engine.execute(query, timeout=0.05)
    except TimeoutError as error:
        elapsed = time.monotonic() - start
        assert str(error) == 'Query timeout exceeded'
    else:
        raise AssertionError('Workload unexpectedly completed before deadline')
    time.sleep(0.05)  # Observe CPU only after abort acknowledgements can run.
    before_cpu = cpu()
    start_idle = time.monotonic()
    time.sleep(0.25)
    idle_wall = time.monotonic() - start_idle
    idle_cpu = cpu() - before_cpu
    assert engine.execute(normal).to_pylist() == expected
    observations.append({'deadline_s': 0.05, 'return_elapsed_s': elapsed,
                         'observed_return_delay_after_deadline_s': max(0.0, elapsed - 0.05),
                         'idle_wall_s': idle_wall, 'idle_process_cpu_s': idle_cpu,
                         'reuse': 'passed'})
for _ in range(5):
    for timeout in (None, 60.0):
        assert engine.execute(normal, timeout=timeout).to_pylist() == expected
pairs = []
for index in range(args.overhead_pairs):
    sample = {}
    for timeout in ((None, 60.0) if index % 2 == 0 else (60.0, None)):
        start = time.perf_counter_ns()
        result = engine.execute(normal, timeout=timeout)
        elapsed = (time.perf_counter_ns() - start) / 1e9
        assert elapsed > 0 and result.to_pylist() == expected
        sample['disabled_s' if timeout is None else 'enabled_s'] = elapsed
    sample['enabled_over_disabled'] = sample['enabled_s'] / sample['disabled_s']
    pairs.append(sample)
result = {'source_revision': proof['source_commit'], 'wheel_sha256': proof['wheel_sha256'],
          'loaded_module': str(module), 'extension_sha256': module_hash,
          'platform': platform.platform(), 'deadline_observations': observations,
          'normal_query': normal, 'overhead_pairs': pairs,
          'mean_disabled_s': statistics.mean(x['disabled_s'] for x in pairs),
          'mean_enabled_s': statistics.mean(x['enabled_s'] for x in pairs),
          'paired_geomean_enabled_over_disabled': math.exp(statistics.mean(
              math.log(x['enabled_over_disabled']) for x in pairs)),
          'limits': ['Supporting observations, not hard real-time or global CPU guarantees.',
                     'Expiry stage is not inferred from elapsed time; deterministic native polling/drop tests are separate.',
                     'Idle wall is captured before the engine-reuse query; historical v1 included that query.']}
print(json.dumps(result, indent=2))
