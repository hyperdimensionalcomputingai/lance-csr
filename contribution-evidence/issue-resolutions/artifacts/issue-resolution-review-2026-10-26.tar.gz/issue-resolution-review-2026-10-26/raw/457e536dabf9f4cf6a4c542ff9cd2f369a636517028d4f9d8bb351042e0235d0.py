"""Package frozen source refs and the raw records referenced by the review packet."""
import hashlib,json,shutil,subprocess,sys,tarfile
from collections import deque
from pathlib import Path
root=Path('/private/tmp/lance-csr-submissions')
evidence=Path('/private/tmp/lance-csr-resolution-evidence/contribution-evidence/issue-resolutions')
repo=Path('/Users/davidhughes/dev/lance-csr')
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
def digest(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
shutil.copytree(evidence,out/'review')
heads=json.loads((evidence/'review-heads-current.json').read_text())
branches={'refs/heads/'+row['proposed_branch'] for row in heads['submissions']}|{'refs/heads/main','refs/heads/codex/issue-resolution-final','refs/heads/codex/issue-resolution-evidence'}
cohorts={cell['source_commit'] for cell in json.loads((root/'frozen-acceptance-combined-r10/manifest.json').read_text())['cells']}
refs=subprocess.check_output(['git','-C',str(repo),'for-each-ref','--format=%(objectname) %(refname)','refs/heads/codex/'],text=True).splitlines()
for commit in cohorts:
 aliases=[line.split(' ',1)[1] for line in refs if line.split(' ',1)[0]==commit]
 if aliases:branches.add(sorted(aliases)[0])
 else:assert any(subprocess.run(['git','-C',str(repo),'merge-base','--is-ancestor',commit,ref],capture_output=True).returncode==0 for ref in branches),commit
branches=sorted(branches)
for row in heads['submissions']:
 assert subprocess.check_output(['git','-C',str(repo),'rev-parse',row['proposed_branch']],text=True).strip()==row['head']
subprocess.run(['git','-C',str(repo),'bundle','create',str(out/'source.bundle'),*branches],check=True)
subprocess.run(['git','-C',str(repo),'bundle','verify',str(out/'source.bundle')],check=True,capture_output=True)
queue=deque();seen=set();raw_index=[];raw=out/'raw';raw.mkdir()
def include(path):
 p=Path(path)
 if not p.is_file() or p.suffix not in {'.json','.jsonl','.log','.txt','.csv','.py','.sh','.patch'}:return
 if not str(p).startswith(('/private/tmp/lance-csr-submissions/','/private/tmp/lance-csr-runtime/')):return
 name=str(p)
 if name in seen:return
 seen.add(name);sha=digest(p);dest=raw/(sha+p.suffix)
 if not dest.exists():shutil.copyfile(p,dest)
 assert digest(dest)==sha
 raw_index.append({'original':name,'included':str(dest.relative_to(out)),'sha256':sha,'bytes':p.stat().st_size})
 if p.suffix=='.json':queue.append(p)
def walk(value):
 if isinstance(value,dict):
  for child in value.values():walk(child)
 elif isinstance(value,list):
  for child in value:walk(child)
 elif isinstance(value,str) and value.startswith('/private/tmp/lance-csr-'):include(value)
# Portable audit packet, including ignored verbatim logs copied beside receipts.
include(Path(__file__).resolve())
for p in (out/'review').rglob('*.json'):
 try:walk(json.loads(p.read_text()))
 except (UnicodeDecodeError,json.JSONDecodeError):pass
# Full-workload reports are located by frozen cell label rather than a JSON path field.
for manifest in [root/'frozen-acceptance-combined-r10/manifest.json']:
 include(manifest)
 d=json.loads(manifest.read_text());assert d['status']=='complete'
 for cell in d['cells']:
  p=manifest.parent/(cell['label']+'.json');assert digest(p)==cell['report_sha256'];include(p);include(cell['log'])
# Preserve executed repeat reports, including the initial gates and fixed-size studies.
for name in ['frozen-flag-repeats-final-r1','entity-precision-study-r1','fused-owners-primary-repeats-r1','final-heads-primary-repeats-r1','scan-budget-primary-repeats-r1','scan-budget-ic6-precision-r1','combined-budget-primary-repeats-r1']:
 p=root/name/'plan.json';include(p);d=json.loads(p.read_text());assert d['status']=='complete'
 for row in d['runs']:
  assert row['status']=='passed';report=p.parent/(row['label']+'.json');log=p.parent/(row['label']+'.log')
  assert digest(report)==row['report_sha256'] and digest(log)==row['log_sha256'];include(report);include(log)
while queue:
 p=queue.popleft()
 try:walk(json.loads(p.read_text()))
 except (UnicodeDecodeError,json.JSONDecodeError):pass
(out/'raw-index.json').write_text(json.dumps(raw_index,indent=2)+'\n')
(out/'README.md').write_text('''# lance-csr local review artifact

Start with `review/pr-drafts/README.md`, `review/review-heads-current.json` and `review/REPRODUCE.md`. Original failed gates remain intact; current acceptance and coordinated integration requirements are explicit.

`source.bundle` preserves all proposed source refs, main and the evidence branch. Verify it with `git bundle verify source.bundle` from an existing clone, then fetch the desired recorded ref from the bundle. No remote publication has occurred.

Run `shasum -a 256 -c SHA256SUMS` in this directory. `raw-index.json` maps original machine paths in immutable receipts to included content-addressed records. These paths are provenance, not prerequisites for regeneration; use the reproduction guide for a new checkout. Wheel digests are pinned, but wheels, build caches, source SF1 tables and archives are excluded. Derived golden query answers are included.

Submitted by David Hughes (@stugorf), with AI Collaboration.
''')
checks=[p for p in sorted(out.rglob('*')) if p.is_file()]
(out/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(out)}\n' for p in checks))
archive=out.with_suffix('.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as bundle:bundle.add(out,arcname=out.name)
# Check every archived regular file against its staged bytes, not only the file list.
with tarfile.open(archive,'r:gz') as bundle:
 members=[m for m in bundle.getmembers() if m.isfile()];assert len(members)==len(checks)+1
 for member in members:
  relative=Path(member.name).relative_to(out.name)
  with bundle.extractfile(member) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==digest(out/relative)
archive.with_suffix(archive.suffix+'.sha256').write_text(f'{digest(archive)}  {archive.name}\n')
print(json.dumps({'archive':str(archive),'sha256':digest(archive),'bytes':archive.stat().st_size,'raw_records':len(raw_index),'source_refs':len(branches)}))
