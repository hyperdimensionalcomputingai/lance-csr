"""Verify installed payloads and the complete copied Python suite without Rust."""
import hashlib, importlib.metadata as metadata, json, pathlib, sys, zipfile
import pytest
import lance_csr
from lance_csr import _internal
wheel=pathlib.Path(sys.argv[1]); package=pathlib.Path(lance_csr.__file__).parent
assert 'site-packages' in package.parts, package
with zipfile.ZipFile(wheel) as archive:
    assert not any('__pycache__' in name for name in archive.namelist())
    for name in archive.namelist():
        if name.startswith('lance_csr/') and not name.endswith('/'):
            assert (package.parent/name).read_bytes()==archive.read(name), name
print(json.dumps({'python':sys.version, 'extension':_internal.__file__,
    'extension_sha256':hashlib.sha256(pathlib.Path(_internal.__file__).read_bytes()).hexdigest(),
    'lance-csr':metadata.version('lance-csr'), 'pyarrow':metadata.version('pyarrow'),
    'pylance':metadata.version('pylance')}),flush=True)
code=pytest.main(['tests','-q','-o','pythonpath='])
assert code==0, code
print('Installed wheel payload and tests passed without Rust',flush=True)
