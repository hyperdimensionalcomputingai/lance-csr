"""Keep first-pass results and classify prospectively selected paired repeats."""
import csv
import hashlib
import json
from pathlib import Path
import re

root=Path('/private/tmp/lance-csr-submissions')
comparisons=json.loads((root/'submit-comparisons/index.json').read_text())['comparisons']
selection=json.loads((root/'submit-repeat-selection.json').read_text())
repeats_dir=root/'submit-paired-repeats'
assert selection['groups']
repeats=json.loads((repeats_dir/'plan.json').read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert repeats['status']=='complete'
assert repeats['selection_sha256']==digest(root/'submit-repeat-selection.json')
def means(run):
 path=repeats_dir/(run['label']+'.json')
 assert digest(path)==run['report_sha256']
 assert digest(repeats_dir/(run['label']+'.log'))==run['log_sha256']
 return {int(re.search(r'(\d+)$',r['name'])[1]):r['stats']['mean'] for r in json.loads(path.read_text())['benchmarks']}
groups={}
for number,group in enumerate(selection['groups'],1):
 runs=[r for r in repeats['runs'] if r['group']==number]
 assert len(runs)==4 and all(r['status']=='passed' for r in runs)
 data={(r['repeat'],r['role']):means(r) for r in runs}
 assert len(data)==4
 groups[tuple(group[k] for k in ('before','after','suite','mode'))]={q:[data[n,'after'][q]/data[n,'before'][q] for n in (1,2)] for q in group['queries']}
rows=[];survivors=[]
for comparison in comparisons:
 key=tuple(comparison[k] for k in ('before','after','suite','mode'))
 initial=json.loads(Path(comparison['report']).read_text())
 bad=[]
 for item in initial['rows']:
  q=item['query'];pair=groups.get(key,{}).get(q,[])
  if q not in comparison['flags_above_10_percent']:status='not_flagged_first_pass'
  else:
   assert len(pair)==2,(key,q)
   status='repeatable_regression' if all(r>1.1 for r in pair) else 'not_repeatable'
   if status=='repeatable_regression':bad.append(q)
  rows.append(dict(zip(('before','after','suite','mode'),key))|{'query':q,'first_after_over_before':item['after_over_before'],'repeat_1_after_over_before':pair[0] if pair else '', 'repeat_2_after_over_before':pair[1] if pair else '', 'status':status})
 comparison['repeatable_regressions']=bad
 comparison['acceptance']='blocked_pending_precision' if bad else 'passed_performance_gate'
 if bad:survivors.append(dict(zip(('before','after','suite','mode'),key))|{'queries':bad})
out=root/'submit-gates';out.mkdir(exist_ok=False)
with (out/'queries.csv').open('x',newline='') as target:
 writer=csv.DictWriter(target,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
result={'rule':selection['rule'],'first_comparison_index_sha256':digest(root/'submit-comparisons/index.json'),'repeat_plan_sha256':digest(repeats_dir/'plan.json'),'comparisons':comparisons,'surviving_groups':survivors,'all_passed':not survivors}
(out/'gates.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'submit-precision-selection.json').write_text(json.dumps({'rule':'For each surviving query, run five fresh alternating pairs with at least 1000 rounds and a three-second target window. Readiness requires median after/before <=1.10 and at least four of five pairs <=1.10; otherwise investigate with a separately declared control or report blocked. Original first-pass and paired flags remain immutable.','groups':survivors},indent=2)+'\n')
print(json.dumps({'all_passed':not survivors,'surviving_groups':survivors},indent=2))
