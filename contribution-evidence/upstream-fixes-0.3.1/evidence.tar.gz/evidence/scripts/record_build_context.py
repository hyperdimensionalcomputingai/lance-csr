import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

phase, target = sys.argv[1:]
out = Path('/private/tmp/lance-csr-submissions/wheels') / phase
proof_path = out / 'release-proof.json'
proof = json.loads(proof_path.read_text())
build_log = Path(proof['build_log'])
text = build_log.read_text()
match = re.search(r'Found CPython ([0-9.]+) at (.+)', text)
assert match, 'Build interpreter not present in build log'
interpreter = Path(match.group(2))
version = json.loads(subprocess.check_output([
    str(interpreter), '-c', 'import json,platform,sys; print(json.dumps({"version":sys.version,"version_info":list(sys.version_info[:3]),"implementation":platform.python_implementation(),"executable":sys.executable}))'
], text=True))
assert '.'.join(map(str, version['version_info'][:2])) == match.group(1)
configs = []
for path in Path(target).glob('release/build/pyo3-build-config-*/out/pyo3-build-config.txt'):
    raw = path.read_text()
    fields = dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)
    if fields.get('executable') == str(interpreter):
        configs.append((path, raw, fields))
assert len(configs) == 1, configs
config_path, config_raw, config_fields = configs[0]

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

record = {
    'phase': phase,
    'source_commit': proof['source_commit'],
    'wheel_sha256': proof['wheel_sha256'],
    'release_proof_path': str(proof_path),
    'release_proof_sha256': digest(proof_path),
    'build_log_path': str(build_log),
    'build_log_sha256': digest(build_log),
    'build_interpreter': {'requested_path': str(interpreter), 'resolved_path': str(interpreter.resolve()), 'binary_sha256': digest(interpreter), **version},
    'pyo3_config_path': str(config_path),
    'pyo3_config_sha256': digest(config_path),
    'pyo3_config': config_fields,
    'pyo3_config_text': config_raw,
    'note': 'PyO3 version=3.12 denotes the abi3 minimum; build_interpreter records the actual build runtime. Consumer Python is recorded separately in release-proof.json. No SF1 comparisons across mismatched build contexts.',
}
with (out / 'build-context.json').open('x') as destination:
    json.dump(record, destination, indent=2)
    destination.write('\n')
print(json.dumps({'phase': phase, 'build_python': version['version_info'], 'context': str(out/'build-context.json')}))
