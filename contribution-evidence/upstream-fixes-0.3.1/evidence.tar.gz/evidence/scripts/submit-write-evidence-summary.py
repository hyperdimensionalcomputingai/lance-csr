"""Write the review summary from immutable receipts, never from assumed results."""
import hashlib
import json
from pathlib import Path
root=Path('/private/tmp/lance-csr-submissions')
out=Path('/private/tmp/lance-csr-upstream-publication/contribution-evidence/upstream-fixes-0.3.1')
status=json.loads((out/'STATUS.json').read_text())
gates=json.loads((out/'final-gates.json').read_text());assert gates['all_passed']
rows=['| Upstream issue | Source branch / head | Debug and installed-wheel Python tests |','|---|---|---:|']
for row in status['issues']:
 rows.append(f"| #{row['upstream_issue']} | `{row['branch']}` / `{row['head'][:12]}` | {row['python_tests_passed']:,} |")
performance=['| Issue | Workload | Mode | First-pass geometric speedup | Acceptance |','|---|---|---|---:|---|']
for c in gates['comparisons']:
 performance.append(f"| #{c['after'].split('-')[-1]} | {c['suite']} | {c['mode']} | {c['geometric_mean_speedup']:.3f}x | {c['acceptance']} |")
body=f'''# Three upstream bug fixes: 0.3.1 publication evidence

All three fixes are committed and pushed on independent feature branches. Each is prepared for a separate PR in `hyperdimensionalcomputingai/lance-csr`, referencing the inherited upstream bugs. Nothing is merged and no release is published. The [current publication receipt](https://github.com/hyperdimensionalcomputingai/lance-csr/blob/codex/upstream-fix-evidence-031/contribution-evidence/upstream-fixes-0.3.1/PUBLISHED_PRS.md) records the resulting PR URLs and verified state.

{chr(10).join(rows)}

Tested base: `{status['tested_base']}`. Observed main: `{status['observed_main']}`. The later main commit changes documentation links and package URL metadata only: runtime source paths and all dependency locks are unchanged. Each PR applies cleanly to that main; the exact local integration checks and diff are inside the archive. The old 0.2.0 review package is historical and is not performance evidence for these new heads.

## What changed and what remains

- **#123:** protect empty-input distinct counts from DataFusion's unsafe statistics shortcut using a query-local frame. Keep the caller state, other optimizer rules, custom planner and deadline context. Existing aggregate AST traversal is reused from main.
- **#105:** bind graph scan fields to their physical Arrow spelling before applying normalized Cypher names, with shared schema lookup for inline filters and exact-field handling when reversing edges.
- **#101:** accept one optional final query semicolon; continue rejecting extra statements and repeated terminators.

After each fix its listed bug is resolved by that branch; after all three, no bug from this three-item scope remains. The feature requests deferred from this work remain **untyped variable-length relationships (#104), factorized intermediates (#163), optional Lance/DataFusion-only builds (#171), and JNI (#115)**. Fork PRs do not automatically close upstream issues.

Each code submission includes focused Rust/Python regressions and a Cypher guide update. Public Python signatures, stubs and dependencies are unchanged.

## Correctness and build policy

Every candidate passed debug workspace tests, Clippy with warnings denied, formatting, a rebuilt Python extension (`make install`), the complete Python suite, Ruff/Pyright, executable documentation snippets, strict Zensical and pinned typos 1.26.0. **All three debug gates passed before any final production build.** Future correctness checks follow that order: debug first across all proposed PRs, production only for final verification/measurements.

The exact new regression matrices against the verified 0.3.1 debug baseline produced 166 failures / 124 passes: #123 30/94, #105 104/26, #101 32/4. Candidate matrices pass 124, 130 and 36 cases respectively. Full installed-wheel suites pass the totals above; the independently built baseline passes 1,263 tests. Consumers run outside source checkouts with Rust absent from PATH, compare every packaged/installed payload and native digest, and reject packaged bytecode.

## Benchmark acceptance

All four release phases ran both full SF1 suites in memory and lazy modes, serially after builds and functional checks stopped. Original goldens and dataset manifests remain unchanged. Baseline results are reused across the three comparisons only within this newly verified cohort.

{chr(10).join(performance)}

Above 1 is faster. These are unchanged first-pass suite means. Per-query flags and paired/precision investigations stay visible in [final-gates.json](final-gates.json); the [before/after tables](comparisons/) include every query. Unresolved repeatable regressions block readiness. No original observations are overwritten by selected-query checks.

Environment: Apple M4 Max, 16 cores, 128 GiB, macOS arm64; Rust 1.96.0 and Python 3.13.17 for all builds and consumers; identical pinned runtime dependencies and fixture manifests per suite. Workloads: 30-query `6260689` and IC `c185123`. Settings, source/wheel/native hashes, exact commands, hardware and peak process RSS are in the raw manifest and release receipts.

These are local engineering comparisons, not an audited SNB result or performance guarantee. Other operating-system/Python combinations and hosted CI are not qualified by these local runs. PR checks report hosted CI separately.

## Reproduce and inspect

Read [REPRODUCE.md](REPRODUCE.md), [STATUS.json](STATUS.json), [final-gates.json](final-gates.json) and the per-query tables. Download [evidence.tar.gz](evidence.tar.gz), check [its SHA-256](evidence.tar.gz.sha256), then verify the internal [artifact checksums](artifact-checksums.json). The archive contains raw checks, release receipts, benchmark reports/logs, exact scripts and protocols, locks, patches and the main-update check. It contains no datasets or native binaries. Original absolute paths are provenance; the instructions explain how to use independent paths.

Submitted by David Hughes (@stugorf), with AI Collaboration.
'''
(out/'README.md').write_text(body)
print(out/'README.md')
