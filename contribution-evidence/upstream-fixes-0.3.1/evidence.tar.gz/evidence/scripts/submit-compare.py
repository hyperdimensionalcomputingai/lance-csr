"""Compare the frozen current-main cohort without replacing any first-pass result."""
import json
from pathlib import Path
import subprocess
import sys
root=Path('/private/tmp/lance-csr-submissions')
manifest=root/'submit-sf1-final/manifest.json'
state=json.loads(manifest.read_text());assert state['status']=='complete'
out=root/'submit-comparisons';out.mkdir(exist_ok=False)
comparisons=[];groups=[]
for issue in (123,105,101):
 for suite in ('q30','ic'):
  for mode in ('memory','lazy'):
   before=f'submit-main-{suite}-{mode}';after=f'submit-{issue}-{suite}-{mode}'
   output=out/f'{issue}-{suite}-{mode}'
   subprocess.run([sys.executable,str(root/'compare_release_cells_r3.py'),str(manifest),before,after,str(output)],check=True)
   result=json.loads(output.with_suffix('.json').read_text())
   row={'before':'submit-main','after':f'submit-{issue}','suite':suite,'mode':mode,'report':str(output.with_suffix('.json')),'geometric_mean_speedup':result['geometric_mean_speedup'],'flags_above_10_percent':result['investigate_above_10_percent']}
   comparisons.append(row)
   if row['flags_above_10_percent']:
    groups.append({'before':'submit-main','after':f'submit-{issue}','suite':suite,'mode':mode,'queries':row['flags_above_10_percent']})
(out/'index.json').write_text(json.dumps({'comparisons':comparisons},indent=2)+'\n')
(root/'submit-repeat-selection.json').write_text(json.dumps({'rule':'Retain complete first-pass means. Repeat each query above 1.10 after/before twice in paired/reversed order; both repeats above 1.10 require longer prospectively defined measurements before readiness. Missing or failed measurements cannot pass.','groups':groups},indent=2)+'\n')
print(json.dumps({'comparisons':len(comparisons),'flagged_groups':len(groups),'flagged_queries':sum(len(g['queries']) for g in groups)},indent=2))
