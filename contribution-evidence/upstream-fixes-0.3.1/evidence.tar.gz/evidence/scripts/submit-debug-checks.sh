#!/bin/zsh
set -euo pipefail
export PATH=/private/tmp/lance-csr-runtime/cargo/bin:/opt/homebrew/bin:/Users/davidhughes/.local/bin:/usr/bin:/bin
export CARGO_HOME=/private/tmp/lance-csr-runtime/cargo
export RUSTUP_HOME=/private/tmp/lance-csr-runtime/rustup
export CARGO_TARGET_DIR=/private/tmp/lance-csr-build-target
export CARGO_BUILD_JOBS=2
export PROTOC=/opt/homebrew/bin/protoc
export UV_PROJECT_ENVIRONMENT=/private/tmp/lance-csr-upstream-105/python/.venv
for issue in 123 105 101; do
  root=/private/tmp/lance-csr-submit-$issue
  logs=/private/tmp/lance-csr-runtime/submit-$issue
  cd "$root"
  cargo fmt --all --check > "$logs-format.log" 2>&1
  cargo test --workspace --locked --offline > "$logs-workspace.log" 2>&1
  cargo clippy --workspace --all-targets --locked --offline -- -D warnings > "$logs-clippy.log" 2>&1
  cd python
  make install PYTHON=3.13.17 > "$logs-debug-install.log" 2>&1
  make test > "$logs-python.log" 2>&1
  make lint > "$logs-lint.log" 2>&1
  uv run --no-sync python ../docs/check_snippets.py > "$logs-snippets.log" 2>&1
  cd ..
  uv run --project docs --locked zensical build --strict > "$logs-docs.log" 2>&1
  uvx typos@1.26.0 . > "$logs-typos.log" 2>&1
  git diff --check
  print "$issue debug correctness checks passed"
done
print 'ALL THREE DEBUG GATES PASSED; production phase may begin'
