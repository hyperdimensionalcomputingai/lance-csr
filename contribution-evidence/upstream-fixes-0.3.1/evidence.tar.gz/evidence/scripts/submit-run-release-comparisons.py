"""Run unchanged upstream SF1 tests serially against verified local release wheels.

The input is a JSON list of release-proof.json paths. Run only after all builds
and functional profiling have stopped; this runner does not control other apps.
"""

import argparse
import hashlib
import json
import os
import platform
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

UV = "/Users/davidhughes/.local/bin/uv"
SUITES = {
    "q30": (Path("/private/tmp/lance-csr-benchmark-q30/lance_csr"), 30),
    "ic": (Path("/private/tmp/lance-csr-benchmark-ic/lance_csr"), 14),
}
SUITE_REVISIONS = {
    "q30": "6260689aa1fba4eeb4e99958430386b2fcd13f71",
    "ic": "c185123edd58b37b417bc4deb2fec643fdbd5e61",
}
FLAGS = [
    "--benchmark-min-rounds=5", "--benchmark-min-time=0.000005",
    "--benchmark-max-time=1.0", "--benchmark-timer=time.perf_counter",
    "--benchmark-calibration-precision=10", "--benchmark-warmup=off",
    "--benchmark-warmup-iterations=5", "--benchmark-disable-gc",
    "--benchmark-sort=fullname", "--benchmark-save-data",
]
PROBE = """
import hashlib, importlib.metadata as m, json, sys
from pathlib import Path
from lance_csr import _internal
path = Path(_internal.__file__).resolve()
assert 'site-packages' in path.parts, path
print(json.dumps({'python': sys.version, 'extension': str(path),
 'extension_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
 'packages': {d.metadata['Name'].lower(): d.version for d in m.distributions()},
 'distribution': m.distribution('lance-csr').read_text('direct_url.json')}))
"""


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def git(directory, *args):
    return subprocess.check_output(["git", "-C", str(directory), *args], text=True).strip()


def data_manifest(directory, suite):
    root = directory / "graph_lance" if suite == "ic" else directory.parent / "lance_graph/graph_lance"
    files = sorted(root.glob("*.lance/_versions/*.manifest"))
    assert files, root
    return {str(path.relative_to(root)): digest(path) for path in files}


def check_builds_stopped():
    processes = subprocess.check_output(["ps", "-axo", "comm="], text=True).splitlines()
    active = [p for p in processes if Path(p).name in {"rustc", "cargo", "cargo-clippy", "maturin"}]
    if active:
        raise RuntimeError(f"Builds still active: {active}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("proofs", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--quiescent-confirmed", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    proofs = [Path(p) for p in json.loads(args.proofs.read_text())]
    assert proofs and len(set(proofs)) == len(proofs)
    manifest = {"created_utc": datetime.now(timezone.utc).isoformat(),
                "runner_sha256": digest(__file__), "status": "prepared", "cells": []}
    manifest["hardware"] = {
        "platform": platform.platform(),
        "macos": subprocess.check_output(["sw_vers"], text=True),
        "cpu_and_memory": subprocess.check_output(
            ["sysctl", "hw.model", "hw.memsize", "hw.physicalcpu", "hw.logicalcpu"], text=True),
    }
    for proof_path in proofs:
        proof = json.loads(proof_path.read_text())
        assert proof["profile"] == "release", proof_path
        assert not (proof_path.parent / "qualification-status.json").exists(), proof_path
        wheel = Path(proof["wheel_path"])
        assert digest(wheel) == proof["wheel_sha256"]
        source = Path(proof["source_worktree"])
        context = proof_path.parent / "build-context.json"
        assert context.is_file(), context
        assert git(source, "rev-parse", "HEAD") == proof["source_commit"]
        assert not git(source, "status", "--porcelain", "--untracked-files=no")
        locks = {str(path): digest(source / path) for path in (
            Path("Cargo.lock"), Path("crates/lance-csr-python/Cargo.lock"),
            Path("python/uv.lock"), Path("docs/uv.lock"))}
        for suite, (directory, count) in SUITES.items():
            assert git(directory, "rev-parse", "HEAD") == SUITE_REVISIONS[suite]
            for mode in ("memory", "lazy"):
                label = f"{proof['phase']}-{suite}-{mode}"
                manifest["cells"].append({
                    "label": label, "phase": proof["phase"], "suite": suite,
                    "mode": mode, "query_count": count, "cwd": str(directory),
                    "proof": str(proof_path), "proof_sha256": digest(proof_path),
                    "build_context": str(context), "build_context_sha256": digest(context),
                    "source_commit": proof["source_commit"], "wheel": str(wheel),
                    "source_lock_sha256": locks,
                    "extension_sha256": proof["extension_sha256"],
                    "suite_revision": git(directory, "rev-parse", "HEAD"),
                    "data_manifests": data_manifest(directory, suite), "status": "pending",
                })
    record = args.output / "manifest.json"

    def save():
        record.write_text(json.dumps(manifest, indent=2) + "\n")

    save()
    if not args.execute:
        print(f"Prepared {len(manifest['cells'])} cells: {record}")
        return
    assert args.quiescent_confirmed, "Finish builds and functional profiling first"
    check_builds_stopped()
    runtimes = {}
    manifest["status"] = "running"
    for cell in manifest["cells"]:
        check_builds_stopped()
        directory = Path(cell["cwd"])
        assert data_manifest(directory, cell["suite"]) == cell["data_manifests"]
        assert not git(directory, "status", "--porcelain", "--untracked-files=no")
        env = os.environ.copy()
        env.pop("WRITE_GOLDEN", None)
        env["LANCE_CSR_MODE"] = cell["mode"]
        prefix = [UV, "run", "--offline", "--no-sync", "--with", cell["wheel"]]
        runtime = json.loads(subprocess.check_output(
            [*prefix, "python", "-I", "-c", PROBE], cwd=directory, env=env, text=True))
        assert runtime["extension_sha256"] == cell["extension_sha256"]
        comparable = {"python": runtime["python"], "packages": runtime["packages"]}
        prior = runtimes.setdefault(cell["suite"], comparable)
        assert prior == comparable, "Runtime dependencies changed between candidates"
        cell["runtime"] = runtime
        report = args.output.resolve() / f"{cell['label']}.json"
        log_path = args.output.resolve() / f"{cell['label']}.log"
        command = [*prefix, "pytest", "benchmark_query.py", "-q", *FLAGS,
                   f"--benchmark-json={report}"]
        cell["command"] = command
        cell["started_utc"] = datetime.now(timezone.utc).isoformat()
        cell["load_average_before"] = os.getloadavg()
        started = time.monotonic()
        with log_path.open("x") as log:
            result = subprocess.run(["/usr/bin/time", "-l", *command], cwd=directory,
                                    env=env, stdout=log, stderr=subprocess.STDOUT)
        cell.update(returncode=result.returncode, elapsed_seconds=time.monotonic() - started,
                    log=str(log_path), log_sha256=digest(log_path))
        rss = re.search(r"(\d+)\s+maximum resident set size", log_path.read_text())
        cell["peak_process_rss_bytes"] = int(rss[1]) if rss else None
        unchanged = data_manifest(directory, cell["suite"]) == cell["data_manifests"]
        valid = result.returncode == 0 and report.exists() and unchanged
        if valid:
            rows = json.loads(report.read_text())["benchmarks"]
            numbers = [int(re.search(r"(\d+)$", row["name"])[1]) for row in rows]
            valid = sorted(numbers) == list(range(1, cell["query_count"] + 1))
            cell["report_sha256"] = digest(report)
        cell["status"] = "passed" if valid else "failed_or_unverified"
        save()
        print(json.dumps({"cell": cell["label"], "status": cell["status"]}), flush=True)
        if not valid:
            manifest["status"] = "failed_or_unverified"
            save()
            raise RuntimeError(f"Incomplete or failed cell: {log_path}")
    manifest["status"] = "complete"
    save()


if __name__ == "__main__":
    main()
