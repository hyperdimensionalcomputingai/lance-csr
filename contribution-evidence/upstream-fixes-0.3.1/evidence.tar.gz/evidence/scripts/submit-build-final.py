"""Build final wheels only after every candidate's debug gate has passed."""
from pathlib import Path
import json,os,shutil,subprocess,time
logs=Path('/private/tmp/lance-csr-runtime')
assert 'ALL THREE DEBUG GATES PASSED' in (logs/'submit-debug-driver.log').read_text()
rows=[('submit-main','/private/tmp/lance-csr-upstream-current-main')]+[(f'submit-{n}',f'/private/tmp/lance-csr-submit-{n}') for n in [123,105,101]]
record={'workflow':'All candidate debug checks passed before any final production build.','builds':[]}
path=logs/'submit-final-builds.json'
def save():path.write_text(json.dumps(record,indent=2)+'\n')
processes=[]
for phase,folder in rows:
 root=Path(folder);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
 target=Path('/private/tmp')/f'lance-csr-release-target-{phase}'
 assert not target.exists()
 subprocess.run(['cp','-cR','/private/tmp/lance-csr-release-target-upstream-fixes',str(target)],check=True)
 output=Path('/private/tmp/lance-csr-submissions/wheels')/phase;output.mkdir()
 for cache in (root/'python/python/lance_csr').rglob('__pycache__'):shutil.rmtree(cache)
 env=os.environ.copy();env.update(PATH='/private/tmp/lance-csr-runtime/cargo/bin:/opt/homebrew/bin:/Users/davidhughes/.local/bin:/usr/bin:/bin',CARGO_HOME='/private/tmp/lance-csr-runtime/cargo',RUSTUP_HOME='/private/tmp/lance-csr-runtime/rustup',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',PROTOC='/opt/homebrew/bin/protoc',CARGO_NET_OFFLINE='true')
 with (logs/f'{phase}-release-clean.log').open('x') as log:
  subprocess.run(['cargo','clean','--release','--manifest-path','../crates/lance-csr-python/Cargo.toml','-p','lance-csr','-p','lance-csr-catalog','-p','lance-csr-python'],cwd=root/'python',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 command=['/private/tmp/lance-csr-upstream-123/python/.venv/bin/maturin','build','--release','--locked','--interpreter','/private/tmp/lance-csr-upstream-123/python/.venv/bin/python','--out',str(output)]
 log=(logs/f'{phase}-release-wheel-build.log').open('x');process=subprocess.Popen(command,cwd=root/'python',env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'phase':phase,'source':str(root),'head':head,'target':str(target),'wheel_output':str(output),'command':command,'status':'building'};record['builds'].append(row);processes.append((process,log,row));save()
for process,log,row in processes:
 code=process.wait();log.close();row['returncode']=code;row['status']='built' if code==0 else 'failed';save();print(json.dumps(row),flush=True)
assert all(row['status']=='built' for row in record['builds'])
record['status']='complete';save()
