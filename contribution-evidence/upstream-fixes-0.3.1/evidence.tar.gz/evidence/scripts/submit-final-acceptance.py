"""Serialize final installed-wheel tests and the unchanged SF1 acceptance suite."""
from pathlib import Path
import json
import subprocess
import sys
import time
root=Path('/private/tmp/lance-csr-submissions')
logs=Path('/private/tmp/lance-csr-runtime')
while True:
    state=json.loads((logs/'submit-final-builds.json').read_text())
    assert all(row['status'] != 'failed' for row in state['builds']),state
    if state.get('status') == 'complete': break
    time.sleep(2)
print('All final builds complete; starting serial installed-wheel consumers',flush=True)
subprocess.run([sys.executable,str(root/'submit-final-consumers.py')],check=True)
print('Final consumers complete; starting serial SF1 cells',flush=True)
subprocess.run([sys.executable,str(root/'submit-run-release-comparisons.py'),str(root/'submit-proofs.json'),str(root/'submit-sf1-final'),'--execute','--quiescent-confirmed'],check=True)
print('Final SF1 cells complete',flush=True)
