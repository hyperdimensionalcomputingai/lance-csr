"""Run final 0.3.1 wheel acceptance serially, after the debug-first build cohort."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/private/tmp/lance-csr-submissions')
LOGS = Path('/private/tmp/lance-csr-runtime')
UV = '/Users/davidhughes/.local/bin/uv'
consumer_root = Path('/private/tmp/lance-csr-release-consumers')
manifest = json.loads((LOGS / 'submit-final-builds.json').read_text())
assert len(manifest['builds']) == 4 and all(b['status'] == 'built' for b in manifest['builds']), manifest
verifier = '''"""Verify installed payloads and the complete copied Python suite without Rust."""
import hashlib, importlib.metadata as metadata, json, pathlib, sys, zipfile
import pytest
import lance_csr
from lance_csr import _internal
wheel=pathlib.Path(sys.argv[1]); package=pathlib.Path(lance_csr.__file__).parent
assert 'site-packages' in package.parts, package
with zipfile.ZipFile(wheel) as archive:
    assert not any('__pycache__' in name for name in archive.namelist())
    for name in archive.namelist():
        if name.startswith('lance_csr/') and not name.endswith('/'):
            assert (package.parent/name).read_bytes()==archive.read(name), name
print(json.dumps({'python':sys.version, 'extension':_internal.__file__,
    'extension_sha256':hashlib.sha256(pathlib.Path(_internal.__file__).read_bytes()).hexdigest(),
    'lance-csr':metadata.version('lance-csr'), 'pyarrow':metadata.version('pyarrow'),
    'pylance':metadata.version('pylance')}),flush=True)
code=pytest.main(['tests','-q','-o','pythonpath='])
assert code==0, code
print('Installed wheel payload and tests passed without Rust',flush=True)
'''
expected = {'submit-main':1263, 'submit-123':1387, 'submit-105':1393, 'submit-101':1299}
for build in manifest['builds']:
    phase=build['phase']; source=Path(build['source']); destination=consumer_root/phase
    destination.mkdir(exist_ok=False)
    for name in ('pyproject.toml','uv.lock'):
        shutil.copy2(source/'python'/name,destination/name)
    shutil.copytree(source/'python/python/tests',destination/'tests',ignore=shutil.ignore_patterns('__pycache__'))
    (destination/'verify.py').write_text(verifier)
    wheel,=Path(build['wheel_output']).glob('*.whl')
    env=os.environ.copy(); env['PATH']='/usr/bin:/bin'; env.pop('UV_PROJECT_ENVIRONMENT',None); env.pop('PYTHONPATH',None)
    log=LOGS/f'{phase}-release-wheel-verification.log'
    with log.open('x') as stream:
        for command in ([UV,'sync','--offline','--locked','--no-install-project','--python','3.13.17'],
                        [UV,'run','--offline','--no-sync','--with',str(wheel),'python','-I','verify.py',str(wheel)]):
            subprocess.run(command,cwd=destination,env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
    text=log.read_text(); assert f"{expected[phase]} passed" in text,text[-3000:]
    subprocess.run([sys.executable,str(ROOT/'submit-record-release.py'),phase,str(source)],check=True)
    subprocess.run([sys.executable,str(consumer_root/'record_build_context.py'),phase,build['target']],check=True)
    print(f'{phase}: {expected[phase]} installed-wheel tests passed',flush=True)
print('ALL FOUR FINAL RELEASE CONSUMERS PASSED',flush=True)
