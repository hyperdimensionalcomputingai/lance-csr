"""Publishable evidence for the exact three current-base PR commits (no binaries/data)."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone

root=Path('/private/tmp/lance-csr-submissions')
logs=Path('/private/tmp/lance-csr-runtime')
out=Path('/private/tmp/lance-csr-upstream-publication/contribution-evidence/upstream-fixes-0.3.1')
gates=json.loads((root/'submit-final-gates.json').read_text());assert gates['all_passed'],gates
out.mkdir(parents=True,exist_ok=False)
raw=out/'evidence';raw.mkdir()
def copy(source,destination):
 source=Path(source);target=raw/destination
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd='/Users/davidhughes/dev/lance-csr',text=True).strip()
for issue in (123,105,101):
 for suffix in ('format','workspace','clippy','debug-install','python','lint','snippets','docs','typos'):
  copy(logs/f'submit-{issue}-{suffix}.log',f'debug/{issue}/{suffix}.log')
for name in ('submit-debug-driver.log','submit-main-debug-install.log','submit-main-debug-proof.json','submit-main-before-debug-r2.log','submit-final-builds.json','submit-final-builds-driver.log','submit-final-acceptance-driver.log','submit-finish-benchmarks-driver.log'):
 copy(logs/name,f'workflow/{name}')
for phase in ('submit-main','submit-123','submit-105','submit-101'):
 proof=json.loads((root/'wheels'/phase/'release-proof.json').read_text())
 for name in ('release-proof.json','build-context.json'):
  copy(root/'wheels'/phase/name,f'releases/{phase}/{name}')
 for name in ('release-wheel-build','release-clean','release-wheel-verification'):
  copy(logs/f'{phase}-{name}.log',f'releases/{phase}/{name}.log')
 copy(Path('/private/tmp/lance-csr-release-consumers')/phase/'verify.py',f'releases/{phase}/verify.py')
for folder in ('submit-sf1-final','submit-comparisons','submit-paired-repeats','submit-gates','submit-precision-final'):
 source=root/folder
 if source.exists():shutil.copytree(source,raw/folder)
for name in ('submit-repeat-selection.json','submit-precision-selection.json','submit-final-gates.json','submit-proofs.json'):
 if (root/name).exists():copy(root/name,f'protocols/{name}')
for name in ('submit-final-consumers.py','submit-record-release.py','submit-run-release-comparisons.py','submit-final-acceptance.py','submit-compare.py','submit-repeat-gates.py','submit-finish-benchmarks.py','submit-stage-evidence.py','submit-write-pr-bodies.py','submit-write-evidence-summary.py','run_release_comparisons.py','compare_release_cells_r3.py','repeat_frozen_flags.py','upstream_fixes_precision_r1.py'):
 copy(root/name,f'scripts/{name}')
for name in ('submit-debug-checks.sh','submit-build-final.py'):
 copy(logs/name,f'scripts/{name}')
copy('/private/tmp/lance-csr-release-consumers/record_build_context.py','scripts/record_build_context.py')
base='f5a986e822032a3aa8c52af55ad08e92504ee73c'
heads={123:'80d4438884872ce9d18c528caa1519441a9460ce',105:'e6df15716a052af380e8a5d2da340cc506ecd188',101:'28096751241a8707042091e5012f99ce1f32f594'}
branches={123:'codex/fix-aggregate-predicates',105:'codex/fix-column-casing',101:'codex/fix-trailing-semicolon'}
for issue,head in heads.items():
 (raw/f'patch-{issue}.diff').write_text(git('diff','--binary',base,head)+'\n')
 source=Path(f'/private/tmp/lance-csr-submit-{issue}')
 assert git('rev-parse',branches[issue])==head
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
 for name in ('Cargo.lock','crates/lance-csr-python/Cargo.lock','python/uv.lock','docs/uv.lock'):
  copy(source/name,f'locks/{issue}/{name}')
current=git('rev-parse','origin/main')
(raw/'main-advance.diff').write_text(git('diff',base,current)+'\n')
integration={'tested_base':base,'observed_main':current,'observed_utc':datetime.now(timezone.utc).isoformat(),'runtime_source_paths_unchanged':not git('diff','--name-only',base,current,'--','crates/lance-csr/src','crates/lance-csr-catalog/src','crates/lance-csr-python/src','python/python/lance_csr'),'dependency_locks_unchanged':not git('diff','--name-only',base,current,'--','Cargo.lock','crates/lance-csr-python/Cargo.lock','python/uv.lock','docs/uv.lock'),'note':'After the tested base, main added documentation links and package URL metadata only; benchmark base stays frozen. No branch has been merged.','merge_tree_check':{str(issue):git('merge-tree','--write-tree',current,head) for issue,head in heads.items()}}
assert integration['runtime_source_paths_unchanged'] and integration['dependency_locks_unchanged']
(raw/'integration-check.json').write_text(json.dumps(integration,indent=2)+'\n')
shutil.copy2(root/'submit-publication-reproduce.md',out/'REPRODUCE.md')
shutil.copy2(root/'submit-final-gates.json',out/'final-gates.json')
shutil.copytree(root/'submit-comparisons',out/'comparisons')
for name in ('queries.csv','gates.json'):
 if (root/'submit-gates'/name).exists():shutil.copy2(root/'submit-gates'/name,out/name)
status={'tested_base':base,'observed_main':current,'attribution':'Submitted by David Hughes (@stugorf), with AI Collaboration.','workflow':'Every candidate debug gate passed before any final production build.','benchmark_acceptance':'passed','deferred':['Untyped variable-length relationships (#104)','Factorized intermediates (#163)','Optional Lance / DataFusion-only build (#171)','JNI bindings (#115)'],'issues':[]}
for issue in heads:
 proof=json.loads((root/f'wheels/submit-{issue}/release-proof.json').read_text())
 status['issues'].append({'upstream_issue':issue,'branch':branches[issue],'head':heads[issue],'python_tests_passed':proof['full_python_tests_passed'],'wheel_sha256':proof['wheel_sha256'],'native_sha256':proof['extension_sha256']})
(out/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
files={str(p.relative_to(raw)):digest(p) for p in sorted(raw.rglob('*')) if p.is_file()}
(raw/'artifact-checksums.json').write_text(json.dumps(files,indent=2)+'\n')
archive=out/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as target:target.add(raw,arcname='evidence')
(out/'evidence.tar.gz.sha256').write_text(f'{digest(archive)}  evidence.tar.gz\n')
shutil.copy2(raw/'artifact-checksums.json',out/'artifact-checksums.json')
with tarfile.open(archive) as check:
 for name, expected in files.items():
  assert hashlib.sha256(check.extractfile('evidence/'+name).read()).hexdigest()==expected,name
shutil.rmtree(raw)
print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive),'destination':str(out)},indent=2))
