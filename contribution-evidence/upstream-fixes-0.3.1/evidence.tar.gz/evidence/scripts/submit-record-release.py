"""Record root-owned release artifacts after clean/build/isolated consumer checks."""

import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

phase, source_name = sys.argv[1:]
source = Path(source_name)
root = Path("/private/tmp/lance-csr-submissions")
output = root / "wheels" / phase
wheel, = output.glob("*.whl")
logs = Path("/private/tmp/lance-csr-runtime")
build, clean, verification = [logs / f"{phase}-{suffix}.log" for suffix in (
    "release-wheel-build", "release-clean", "release-wheel-verification")]
assert "Removed" in clean.read_text() and "error:" not in clean.read_text()
assert "Finished `release` profile [optimized]" in build.read_text()
for crate in ("lance-csr-catalog", "lance-csr", "lance-csr-python"):
    assert f"Compiling {crate} v0.3.1 ({source}/crates/{crate})" in build.read_text()
verified = verification.read_text()
assert "without Rust" in verified and "failed" not in verified.lower()
assert subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=source, text=True) == ""
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=source, text=True).split("\0")
untracked = [name for name in untracked if name]
assert not untracked or untracked == ['ChatGPT Image Oct 24, 2026, 12_36_29 PM.png'], untracked


def digest(path):
    with Path(path).open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


with zipfile.ZipFile(wheel) as archive:
    member, = [name for name in archive.namelist() if name.startswith("lance_csr/_internal.") and name.endswith(".so")]
    extension_hash = hashlib.sha256(archive.read(member)).hexdigest()

runtime_root = Path("/private/tmp/lance-csr-runtime/rustup/toolchains/1.96.0-aarch64-apple-darwin/bin")
proof = {
    "created_utc": datetime.now(timezone.utc).isoformat(), "phase": phase,
    "source_worktree": str(source),
    "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip(),
    "tracked_source_clean": True, "preserved_untracked_files": untracked,
    "profile": "release", "wheel_path": str(wheel), "wheel_sha256": digest(wheel),
    "extension_sha256": extension_hash, "installed_extension_matches_archive": True,
    "build_log": str(build), "build_log_sha256": digest(build),
    "release_clean_log": str(clean), "release_clean_log_sha256": digest(clean),
    "verification_log": str(verification), "verification_log_sha256": digest(verification),
    "verification_script_sha256": digest(Path("/private/tmp/lance-csr-release-consumers") / phase / "verify.py"),
    "build_python_lock_sha256": digest(source / "crates/lance-csr-python/Cargo.lock"),
    "toolchain": {tool: subprocess.check_output([str(runtime_root / tool), "--version"], text=True).strip() for tool in ("rustc", "cargo")},
    "installed_environment": next(json.loads(line) for line in verified.splitlines() if line.startswith("{")),
    "full_python_tests_passed": int(re.search(r"(\d+) passed", verified)[1]),
    "limits": ["SF1 comparisons are recorded separately", "No other operating-system matrix", "No merge or release publication"],
    "attribution": "Submitted by David Hughes (@stugorf), with AI Collaboration.",
}
with (output / "release-proof.json").open("x") as destination:
    json.dump(proof, destination, indent=2)
    destination.write("\n")
print(json.dumps({"phase": phase, "source": proof["source_commit"], "wheel_sha256": proof["wheel_sha256"]}))
