"""Repeat flagged queries in two fresh paired/reversed comparisons; no suite reruns."""
import argparse
import hashlib
import json
import os
import re
import subprocess
import time
from pathlib import Path

import run_release_comparisons as common

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('manifest',type=Path)
parser.add_argument('selection',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
m=json.loads(args.manifest.read_text());assert m['status']=='complete'
selection=json.loads(args.selection.read_text());assert selection['groups']
args.output.mkdir(exist_ok=False)
cells={c['label']:c for c in m['cells']}
plan={'status':'running','manifest_sha256':common.digest(args.manifest),'selection_sha256':common.digest(args.selection),'runner_sha256':common.digest(__file__),'rule':selection['rule'],'runs':[]}
record=args.output/'plan.json'
def save():record.write_text(json.dumps(plan,indent=2)+'\n')
save();common.check_builds_stopped()
for number,g in enumerate(selection['groups'],1):
 assert g['queries'] and len(g['queries'])==len(set(g['queries']))
 pair={role:cells[f"{g[role]}-{g['suite']}-{g['mode']}"] for role in ('before','after')}
 assert all(c['status']=='passed' for c in pair.values())
 assert pair['before']['data_manifests']==pair['after']['data_manifests']
 for repeat in (1,2):
  order=('before','after') if repeat==1 else ('after','before')
  for role in order:
   common.check_builds_stopped();c=pair[role];directory=Path(c['cwd'])
   assert common.data_manifest(directory,g['suite'])==c['data_manifests']
   assert common.digest(c['wheel'])==json.loads(Path(c['proof']).read_text())['wheel_sha256']
   label=f'g{number}-r{repeat}-{role}';report=args.output.resolve()/(label+'.json');log=args.output.resolve()/(label+'.log')
   env=os.environ.copy();env.pop('WRITE_GOLDEN',None);env['LANCE_CSR_MODE']=g['mode']
   prefix=[common.UV,'run','--offline','--no-sync','--with',c['wheel']]
   runtime=json.loads(subprocess.check_output([*prefix,'python','-I','-c',common.PROBE],cwd=directory,env=env,text=True))
   assert runtime['extension_sha256']==c['extension_sha256']
   assert runtime['python']==c['runtime']['python'] and runtime['packages']==c['runtime']['packages']
   tests=[f'benchmark_query.py::test_benchmark_query{q}' for q in sorted(g['queries'])]
   command=[*prefix,'python','-m','pytest',*tests,'-q',*common.FLAGS,f'--benchmark-json={report}']
   row={'label':label,'group':number,'before':g['before'],'after':g['after'],'suite':g['suite'],'mode':g['mode'],'repeat':repeat,'role':role,'phase':c['phase'],'queries':g['queries'],'runtime':runtime,'command':command,'status':'running'}
   plan['runs'].append(row);save()
   with log.open('x') as output:result=subprocess.run(command,cwd=directory,env=env,stdout=output,stderr=subprocess.STDOUT)
   row['returncode']=result.returncode;row['log_sha256']=common.digest(log)
   valid=(result.returncode==0 and report.exists() and common.data_manifest(directory,g['suite'])==c['data_manifests'])
   if valid:
    rows=json.loads(report.read_text())['benchmarks'];numbers=[int(re.search(r'(\d+)$',v['name'])[1]) for v in rows]
    valid=sorted(numbers)==sorted(g['queries']);row['report_sha256']=common.digest(report)
   row['status']='passed' if valid else 'failed_or_unverified';save()
   if not valid:
    plan['status']='failed_or_unverified';save();raise RuntimeError(log)
 print(json.dumps({'group':number,'of':len(selection['groups']),'status':'passed'}),flush=True)
plan['status']='complete';save()
