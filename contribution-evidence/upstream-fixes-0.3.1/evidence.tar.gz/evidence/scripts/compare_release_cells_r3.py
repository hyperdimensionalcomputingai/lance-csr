"""Compare complete cells from one release manifest; reuse the docs geomean rule."""

import argparse
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("before")
    parser.add_argument("after")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    cells = {cell["label"]: cell for cell in manifest["cells"]}
    before, after = cells[args.before], cells[args.after]
    assert before["status"] == after["status"] == "passed"
    for key in ("suite", "mode", "suite_revision", "data_manifests"):
        assert before[key] == after[key], key
    contexts = [json.loads(Path(cell["build_context"]).read_text()) for cell in (before, after)]
    def build_version(context):
        value = context["build_interpreter"]
        if isinstance(value, dict):
            if "version_info" in value:
                return value["version_info"]
            match = re.match(r"(\d+)\.(\d+)\.(\d+)", value["version"])
            assert match, value
            return [int(part) for part in match.groups()]
        return [int(part) for part in context["python_version"].split(".")]
    assert build_version(contexts[0]) == build_version(contexts[1]), "Build interpreters differ"
    assert before["runtime"]["python"] == after["runtime"]["python"]
    assert before["runtime"]["packages"] == after["runtime"]["packages"]

    def results(cell):
        path = args.manifest.parent / f"{cell['label']}.json"
        assert digest(path) == cell["report_sha256"]
        rows = json.loads(path.read_text())["benchmarks"]
        output = {int(re.search(r"(\d+)$", row["name"])[1]): row["stats"] for row in rows}
        assert sorted(output) == list(range(1, cell["query_count"] + 1))
        assert all(math.isfinite(row["mean"]) and row["mean"] > 0 for row in output.values())
        return output

    baseline, candidate = results(before), results(after)
    assert baseline.keys() == candidate.keys()
    docs = Path("/Users/davidhughes/dev/lance-csr/docs/sync_benchmarks.py")
    spec = importlib.util.spec_from_file_location("benchmark_documentation", docs)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ratio, count = module.geomean_ratio(
        {n: row["mean"] for n, row in candidate.items()},
        {n: row["mean"] for n, row in baseline.items()},
    )
    assert module.geomean_ratio({1: 1.0, 2: 2.0}, {1: 2.0, 2: 1.0}) == (1.0, 2)
    query_rows = [{"query": n, "before_mean_seconds": baseline[n]["mean"],
                   "after_mean_seconds": candidate[n]["mean"],
                   "after_over_before": candidate[n]["mean"] / baseline[n]["mean"],
                   "before_median_seconds": baseline[n]["median"],
                   "after_median_seconds": candidate[n]["median"]} for n in sorted(baseline)]
    summary = {
        "before": args.before, "after": args.after, "query_count": count,
        "geometric_mean_speedup": ratio,
        "investigate_above_10_percent": [r["query"] for r in query_rows if r["after_over_before"] > 1.1],
        "rows": query_rows, "manifest_sha256": digest(args.manifest),
        "geomean_implementation_sha256": digest(docs),
        "interpretation": "A single comparison flags regressions for repeat measurement; it does not establish repeatability.",
    }
    with args.output.with_suffix(".json").open("x") as output:
        json.dump(summary, output, indent=2)
        output.write("\n")
    lines = [f"{args.before} → {args.after}", "",
             f"{count} queries correct. Geometric mean speedup: {ratio:.3f}× (above 1 is faster).", "",
             "| Query | Before mean ms | After mean ms | After / before |",
             "| --- | ---: | ---: | ---: |"]
    for row in query_rows:
        lines.append(f"| {row['query']} | {row['before_mean_seconds'] * 1000:.3f} | {row['after_mean_seconds'] * 1000:.3f} | {row['after_over_before']:.3f} |")
    lines += ["", "Queries above 10% are candidates for repeat measurement, not established regressions.",
              "Raw reports, software/build contexts, data hashes and commands are linked by the manifest."]
    with args.output.with_suffix(".md").open("x") as output:
        output.write("\n".join(lines) + "\n")
    print(json.dumps({key: summary[key] for key in ("query_count", "geometric_mean_speedup", "investigate_above_10_percent")}))


if __name__ == "__main__":
    main()
