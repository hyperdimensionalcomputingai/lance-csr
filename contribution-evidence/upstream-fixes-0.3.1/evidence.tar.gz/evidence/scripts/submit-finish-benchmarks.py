"""Finish only the acceptance measurements required by the frozen first-pass flags."""
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time
root=Path('/private/tmp/lance-csr-submissions')
manifest=root/'submit-sf1-final/manifest.json'
while True:
 if manifest.exists():
  m=json.loads(manifest.read_text())
  assert m['status']!='failed_or_unverified',m['status']
  if m['status']=='complete':break
 time.sleep(2)
def run(name,*args):subprocess.run([sys.executable,str(root/name),*map(str,args)],check=True)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
run('submit-compare.py')
selection=json.loads((root/'submit-repeat-selection.json').read_text())
if selection['groups']:
 run('repeat_frozen_flags.py',manifest,root/'submit-repeat-selection.json',root/'submit-paired-repeats')
 run('submit-repeat-gates.py')
 final=json.loads((root/'submit-gates/gates.json').read_text())
else:
 final=json.loads((root/'submit-comparisons/index.json').read_text())|{'all_passed':True,'surviving_groups':[],'note':'No initial per-query flags above 10%; no repeats required.'}
 for c in final['comparisons']:c['acceptance']='passed_performance_gate'
if not final['all_passed']:
 run('upstream_fixes_precision_r1.py',manifest,root/'submit-precision-selection.json',root/'submit-precision-final')
 directory=root/'submit-precision-final'
 plan=json.loads((directory/'plan.json').read_text());assert plan['status']=='complete'
 declared=json.loads((root/'submit-precision-selection.json').read_text())
 assert plan['selection_sha256']==digest(root/'submit-precision-selection.json')
 precision=[]
 def means(row):
  path=directory/(row['label']+'.json');assert digest(path)==row['report_sha256']
  assert digest(directory/(row['label']+'.log'))==row['log_sha256']
  return {int(re.search(r'(\d+)$',v['name'])[1]):v['stats']['mean'] for v in json.loads(path.read_text())['benchmarks']}
 for number,group in enumerate(declared['groups'],1):
  rows=[r for r in plan['runs'] if r['group']==number]
  assert len(rows)==10 and all(r['status']=='passed' for r in rows)
  values={(r['repeat'],r['role']):means(r) for r in rows};assert len(values)==10
  for q in group['queries']:
   ratios=[values[n,'after'][q]/values[n,'before'][q] for n in range(1,6)]
   passed=statistics.median(ratios)<=1.1 and sum(r<=1.1 for r in ratios)>=4
   precision.append({k:group[k] for k in ('before','after','suite','mode')}|{'query':q,'after_over_before_pairs':ratios,'median':statistics.median(ratios),'pairs_within_10_percent':sum(r<=1.1 for r in ratios),'passed':passed})
 for c in final['comparisons']:
  if c['acceptance']=='blocked_pending_precision':
   rows=[r for r in precision if all(r[k]==c[k] for k in ('before','after','suite','mode'))]
   assert rows and sorted(r['query'] for r in rows)==sorted(c['repeatable_regressions'])
   c['acceptance']='passed_precision_gate' if all(r['passed'] for r in rows) else 'blocked_by_repeatable_regression'
 final['precision_rule']=declared['rule'];final['precision']=precision
 final['all_passed']=all(c['acceptance'].startswith('passed_') for c in final['comparisons'])
 final['precision_plan_sha256']=digest(directory/'plan.json')
final['limits']=['First-pass suite means and flags are retained unchanged.','Engineering measurements on one macOS arm64 host; other platforms are unverified.','Golden answers, dataset manifests and benchmark repositories are preserved.']
(root/'submit-final-gates.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'all_passed':final['all_passed'],'comparisons':len(final['comparisons']),'precision':final.get('precision',[])},indent=2),flush=True)
assert final['all_passed'],'Performance acceptance needs investigation; publication not ready.'
